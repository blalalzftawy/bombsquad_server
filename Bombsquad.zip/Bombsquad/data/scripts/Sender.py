import bs
import bsInternal
import bsUI
import bsUtils
from bsUtils import *
import random

Messages = ['Join us now: https://t.me/+fO6sit_fAz5iYzNk']

DelayLength = 90 #Should Be In Seconds

def messager():
	random_msg = random.choice(Messages)
	bsInternal._chatMessage(random_msg)
	return

timer = bs.Timer(DelayLength * 1000, messager, timeType='real', repeat=True)
