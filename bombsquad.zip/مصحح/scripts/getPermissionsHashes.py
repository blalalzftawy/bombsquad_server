adminHashes = []
vipHashes = []
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = ['pb-IF4WUEFdFw==','pb-IF5VU1URJA==','pb-IF42UFQ8KA==']
coownerHashes= []
surroundingObjectEffect = []
sparkEffect = ['pb-IF4WUEFdFw==','pb-IF5VU1URJA==','pb-IF42UFQ8KA==']
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = [] 
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

