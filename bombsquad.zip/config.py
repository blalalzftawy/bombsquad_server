# place any of your own overrides here.
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
# config['partyName'] = "سيرفر بلال"
# config['sessionType'] = 'teams'
# config['maxPartySize'] = 16
# config['port'] = 33849
# config['playlistCode'] = 5
