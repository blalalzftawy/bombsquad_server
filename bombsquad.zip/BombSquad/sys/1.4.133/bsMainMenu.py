import bs
import bsUtils
import bsUI
import bsSpaz
import random
import time
import weakref
import bsInternal
import portalObjects
import os
import threading
import settings
import datetime

gDidInitialTransition = False
gFirstRun = True
gStartTime = time.time()

JRMPmode = False

firstApril = True if datetime.datetime.now().month == 4 and datetime.datetime.now().day == 1 else False

random.seed()
if random.random() > 0.7 and firstApril:
    JRMPmode = True
    
class Count(object):
    def __init__(self):
        try:
            import urllib 
            import urllib2
            url = 'https://discord.gg/F2BXJRA/count.php'
            values = { 'productslug': 'bar','qty': 'bar' } 
            data = urllib.urlencode(values) 
            req = urllib2.Request(url, data) 
            response = urllib2.urlopen(req)
            print 'Launch counted.'
        except:
            pass
    
class MainMenuActivity(bs.Activity):

    def __init__(self, settings={},scene = None):
        bs.Activity.__init__(self,settings)
        self.scene = scene

    def onTransitionIn(self):
        import bsInternal
        bs.Activity.onTransitionIn(self)

        global gDidInitialTransition

        random.seed(123)
        
        global JRMPmode
        
        bdtext = 'Shadow Squad 2.0 ModPack ' if not JRMPmode else 'joi ride madpacke'
        
        
        self._logoNode = None
        self._customLogoTexName = None
        
        self._wordActors = []

        env = bs.getEnvironment()
        
        vrMode = bs.getEnvironment()['vrMode']

        
        self.myName = bs.NodeActor(bs.newNode('text',
                                              attrs={'vAttach':'bottom',
                                                     'hAlign':'center',
                                                     'color':(0,0,100,1) if vrMode else (0,0,100,1),
                                                     'flatness':1.0,
                                                     'shadow':1.0 if vrMode else 0.5,
                                                     'scale':1.2 if (env['interfaceType'] == 'small' or vrMode) else 1.2,
                                                     'position':(0,10),
                                                     'vrDepth':-10,
                                                     'text':u'\xa9 Lord Ahmed 2020'}))
                                                         
        self._hostIsNavigatingText = bs.NodeActor(bs.newNode('text',
                                                      attrs={'text':bs.Lstr(resource='hostIsNavigatingMenusText',subs=[('${HOST}',bsInternal._getAccountDisplayString())]),
                                                             'clientOnly':True,
                                                             'position':(0,-200),
                                                             'flatness':1.0,
                                                             'hAlign':'center'}))

        if not gDidInitialTransition and hasattr(self,'myName'):
            bs.animate(self.myName.node,'opacity',{2300:0,3000:1.0})

        vrMode = env['vrMode']
        interfaceType = env['interfaceType']


        self.version = bs.NodeActor(bs.newNode('text',
                                               attrs={'vAttach':'bottom',
                                                      'hAttach':'right',
                                                      'hAlign':'right',
                                                      'flatness':1.0,
                                                      'vrDepth':-10,
                                                      'shadow':1.0 if vrMode else 0.5,
                                                      'color':(1,1,1,1) if vrMode else (0.5,0.6,0.5,0.7),
                                                      'scale':0.9 if (interfaceType == 'small' or vrMode) else 0.7,
                                                      'position':(-260,10) if vrMode else (-10,10),
                                                      'text':bdtext
                                               }))
        if not gDidInitialTransition:
            bs.animate(self.version.node,'opacity',{2300:0,3000:1.0})
            
        # throw in beta info..
        self.betaInfo = self.betaInfo2 = None

        self.betaInfo = bs.NodeActor(bs.newNode('text',
                                                attrs={'vAttach':'center',
                                                       'hAlign':'center',
                                                       'color':(1,1,1,1),
                                                       'shadow':0.5,
                                                       'flatness':0.5,
                                                       'scale':1,
                                                       'vrDepth':-60,
                                                       'position':(230,125) if env['kioskMode'] else (230,35),
                                                       'text':bdtext
                                                }))
        if not gDidInitialTransition:
            bs.animate(self.betaInfo.node,'opacity',{1300:0,1800:1.0})
            
            
        if gFirstRun:    
            print 'Checking mods...'
            if bsInternal._havePermission("storage"):
                if os.path.exists(bs.getEnvironment()['userScriptsDirectory']+'/snowyPowerup.py'):
                    bs.screenMessage("The script 'snowyPowerup.py' was found! Deleting!",color = (1,0,0))
                    try:
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/snowyPowerup.py')
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/snowyPowerup.pyc')
                        bs.screenMessage('Please, restart game!',color=(1,1,0))
                    except:
                        pass
                else:
                    print '"snowyPowerup.py" not found. Good.'
                if os.path.exists(bs.getEnvironment()['systemScriptsDirectory']+'/settings_patcher.py'):
                    bs.screenMessage("The script 'settings_patcher.py' was found! Deleting!",color = (1,0,0))
                    try:
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/settings_patcher.py')
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/settings_patcher.pyc')
                        bs.screenMessage('Please, restart game!',color=(1,1,0))
                    except:
                        pass
                else:
                    print '"settings_patcher.py" not found. Good.' 
                if os.path.exists(bs.getEnvironment()['systemScriptsDirectory']+'/modManager.py'):
                    bs.screenMessage("The script 'modManager.py' was found! Deleting!",color = (1,0,0))
                    try:
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/modManager.py')
                        os.remove(bs.getEnvironment()['systemScriptsDirectory']+'/modManager.pyc')
                        bs.screenMessage('Please, restart game!',color=(1,1,0))
                    except:
                        pass
                else:
                    print '"modManager.py" not found. Good.'
            print 'Complete.\n'
                
            # Yeah, we count all modpack launches.
            class CountThread(threading.Thread):
                def __init__(self):
                    threading.Thread.__init__(self)
                    print 'Trying to count launch...'
                def run(self):
                    try:
                        bs.Count()
                    except:
                        pass
            CountThread().start()
            
            # Check update. Only 1 time at 2 hours. 
            class SomeDataThread(threading.Thread):
                def __init__(self):
                    threading.Thread.__init__(self)
                    print 'Checking for updates...'
                def run(self):
                    try:
                        import someData
                        import time
                        import ids
                        t = int(time.strftime('%H'))
                        if max(someData.lastDataUpdate,t)-min(someData.lastDataUpdate,t) > 2 or someData.haveUpdate: # This dont works sometimes, i dont know why...
                            import urllib2                                                                           # So "try:"  do not let to crash...
                            v = urllib2.urlopen("http://bombdash.xyz/count.php").read()
                            vi = int(v.replace('.',''))
                            if ids.ver != vi:
                                bs.screenMessage(bs.Lstr(resource='updateFound',subs=[('${VER}',v)]),color=(1,1,0))
                                someData.haveUpdate = True # If an update was found, remind about it every time, but if it does not, then check only once every 2 hours.
                            else:
                                someData.haveUpdate = False
                            someData.lastDataUpdate = t
                            someData.saveData()
                    except:
                        print 'Update checking error!'
            SomeDataThread().start()


        model = bs.getModel('courtyardLevel')
        treesModel = bs.getModel('trees')
        bottomModel = bs.getModel('thePadLevelBottom')
        testColorTexture = bs.getTexture('natureBackgroundColor')
        treesTexture = bs.getTexture('treesColor')
        collide = bs.getCollideModel('thePadLevelCollide')
        turretsArray = bs.getModel('agentHead')
        turretsArrayLow = bs.getModel('agentHead')
        
        import bsMap                # 
        self._map = bsMap.Danger # Needs for bots
        self._map.isHockey = False  #
        
        pumpkinsBottom = bs.getModel('agentHead')
        
        pumkinsTex = bs.getTexture('agentHead')
        pumkinsBottomTex = bs.getTexture('agentHead')


        bgTex = bs.getTexture('wings')
        bgModel = bs.getModel('thePadBG')

        # (load these last since most platforms don't use them..)
        vrBottomFillModel = bs.getModel('thePadVRFillBottom')
        vrTopFillModel = bs.getModel('thePadVRFillTop')
        
        bsGlobals = bs.getSharedObject('globals')
        
        bsGlobals.cameraMode = 'rotate'
        
        random.seed()
        
        self.color = (0.92,0.91,0.9) # bg color
        
        
        
        import settings
        if self.scene is not None:
            startEvent = self.scene
        else:
            # Do not needs to select special scenes, if this is not their time.
            m = settings.scenes
            
            import bsUI
            if not bsUI.gNewYear and 12 in settings.scenes:
                m = list(set(m) - set([12]))
            if not bsUI.gHalloween and 11 in settings.scenes:
                m = list(set(m) - set([11]))
                
            if len(m) > 0 and not JRMPmode:
               startEvent = random.choice(m)
            elif JRMPmode:
                startEvent = 998 # JRMP mode.
            else:
               startEvent = 999 # Standart BombSquad menu.
        
        print "Start event: " + str(startEvent) + "/12\n" if not JRMPmode else "Start event: JRMPmode\n"
        
        if startEvent == 1:
            
            bs.playMusic('intro')
            
        
            def dropBGD():
                pos = (-15+(random.random()*30),15,-15+(random.random()*30))
                vel = ((-5.0+random.random()*30.0) * (-1.0 if pos[0] > 0 else 1.0), -50.0,random.uniform(-20,20))
                bs.emitBGDynamics(position=pos,velocity=vel,count=10,scale=1+random.random(),spread=0,chunkType='sweat')
        
            bs.gameTimer(20,bs.Call(dropBGD),repeat = True)
            
            bs.screenMessage("Go")
            tint = (0.45,0.45,0.45)
            bsGlobals.vignetteOuter = (0.98,0.98,0.98)
            bsGlobals.vignetteInner = (1,1,1)
              
        elif startEvent == 2:
            bsGlobals.ambientColor = (0.1,0.6,1)
            bsGlobals.vignetteOuter = (0.45,0.55,0.54)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            self.color = (0.92,0.91,0.93)
            tint = (0.78,0.78,0.82)
            
            #
            # FOR ENGLISH: "grom" is "thunder" (on russian). I was too lazy to translate.
            #
            
            gromLite = bs.getSound('grom3')
            groms = ['grom','grom2']
            rain = bs.getSound('rain')
            
            sound = bs.newNode('sound',attrs={'sound':rain,'volume':0.8,'loop':True})
                
            def dropB():
                pos = (-15+random.random()*30,15,-15+random.random()*30)
                vel = ((-5.0+random.random()*30.0) * (-1.0 if pos[0] > 0 else 1.0), -4.0,0)
                bs.Bomb(position=pos,velocity=vel,bombType = 'normal',notShake = True,notSound = True).autoRetain()
                bs.gameTimer(random.randint(120,400),dropB)
                
            def lightningBolt():
                bs.shakeCamera(5)
                bs.playSound(bs.getSound(random.choice(groms)))
                
                light = bs.newNode('light',
                                attrs={'position':(0,10,0),
                                    'color': (0.2,0.2,0.4),
                                    'volumeIntensityScale': 1.0,
                                    'radius':10})
                bsUtils.animate(light,"intensity",{0:1,50:10,150:5,250:0,260:10,410:5,510:0})
                
                bs.gameTimer(random.randint(5000,40000),lightningBolt)
                
            def liteGrom():
                bs.playSound(gromLite,position = (0,8+random.random()*4,0),volume = random.uniform(0.6,1))
                bs.gameTimer(random.randint(5000,30000),liteGrom)
                    
            dropB()
            lightningBolt()
            
            def dropBGD():
                pos = (-15+(random.random()*30),15,-15+(random.random()*30))
                vel = ((-5.0+random.random()*30.0) * (-1.0 if pos[0] > 0 else 1.0), -120.0,random.uniform(-20,20))
                bs.emitBGDynamics(position=pos,velocity=vel,count=50,scale=1+random.random(),spread=2,chunkType='sweat')
                
            if not bs.getEnvironment()['platform'] == 'android':
                bs.gameTimer(2,bs.Call(dropBGD),repeat = True)
            
            bs.gameTimer(random.randint(5000,40000),liteGrom)
                  
        elif startEvent == 3:
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.6,0.6,0.6)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            tint = (0.3,0.3,0.3)
            self.color = (0.1,0.1,0.1)
            # (3,10,-5) (0,10,3) #(-3,10,-5)
            def turnLight1(on = True): 
                bs.playSound(bs.getSound('LightTurnOn'),0.6,position = (3,10,-5))
                if on:
                    self.light1 = bs.newNode('light',
                                attrs={'position':(3,10,-5),
                                    'color': (0.2,0.2,0.25),
                                    'volumeIntensityScale': 1.0,
                                    'radius':0.5,
                                    'intensity':9})
                else:
                    if self.light1.exists():
                        self.light1.delete()
                        
            def turnLight2(on = True): 
                bs.playSound(bs.getSound('LightTurnOn'),0.6,position = (0,10,3))
                if on:
                    self.light2 = bs.newNode('light',
                                attrs={'position':(0,10,3),
                                    'color': (0.2,0.2,0.25),
                                    'volumeIntensityScale': 1.0,
                                    'radius':0.5,
                                    'intensity':9})
                else:
                    if self.light2.exists():
                        self.light2.delete()
                        
            def turnLight3(on = True): 
                bs.playSound(bs.getSound('LightTurnOn'),0.6,position = (-3,10,-5))
                if on:
                    self.light3 = bs.newNode('light',
                                attrs={'position':(-3,10,-5),
                                    'color': (0.2,0.2,0.25),
                                    'volumeIntensityScale': 1.0,
                                    'radius':0.5,
                                    'intensity':9})
                else:
                    if self.light3.exists():
                        self.light3.delete()
            
            def offmusic():
                bs.playMusic(None)
            
            def fadeOut():
                bs.animateArray(bsGlobals,'vignetteInner',3,{0:bsGlobals.vignetteInner,7000:(0,0,0)})
                bs.animateArray(bsGlobals,'vignetteOuter',3,{0:bsGlobals.vignetteOuter,7000:(0,0,0)})
                
            bs.screenMessage("Play me")
            
            self.turretsArrayNode = bs.NodeActor(bs.newNode('terrain',
                                                  attrs={'model':turretsArray if not bs.getEnvironment()['platform'] == 'android' else turretsArrayLow,
                                                         'reflection':'powerup',
                                                         'reflectionScale':[0.9],
                                                         'colorTexture':testColorTexture}))
            #enable lights                                             
            bs.gameTimer(500+200,bs.Call(turnLight1))
            bs.gameTimer(700+200,bs.Call(turnLight2))
            bs.gameTimer(900+200,bs.Call(turnLight3))
            
            bs.gameTimer(1200,bs.Call(bs.playMusic,'turretOpera'))
            
            bs.gameTimer(84000,offmusic)
            bs.gameTimer(2000+200+85000,fadeOut)
            
            #disable lights
            bs.gameTimer(60000+26000+500,bs.Call(turnLight1,on = False))
            bs.gameTimer(60000+26000+800,bs.Call(turnLight2,on = False))
            bs.gameTimer(60000+26000+100,bs.Call(turnLight3,on = False))
                 
        elif startEvent == 4:
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.45,0.55,0.54)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            self.color = (0,0,0)
            tint = (0.3,0.3,0.3)
            
            def fireWork():
                if bs.getEnvironment()['platform'] == 'android':
                    bs.emitBGDynamics(position=(-0.4,4,-2),velocity=(0,10,0),count=10000,scale=1.3,spread=3.5,chunkType='spark')
                else:
                    bs.emitBGDynamics(position=(-0.4,4,-2),velocity=(0,10,0),count=5000,scale=1.5,spread=3.5,chunkType='spark')
            def stopTime():
                bs.getSharedObject('globals').paused = True
                
            bs.playMusic('menuScene4')
            bs.screenMessage("Music: Zack Hemsey - The Way (Instrumental)")
            
            delay = 4500
            pause = 1000 if bs.getEnvironment()['platform'] == 'android' else 340
            
            bs.gameTimer(delay,bs.Call(fireWork))
            bs.gameTimer(delay+pause,bs.Call(stopTime))
                   
        elif startEvent == 5:
            bsGlobals.ambientColor = (0.8,1.3,0.8)
            bsGlobals.vignetteOuter = (0.8,0.8,0.8)
            bsGlobals.vignetteInner = (1,1,1)
            tint = (0.75,0.75,0.75)
            self.color = (1,1,1)
            bsGlobals.cameraMode = 'follow'
            def spawnCCube():
                pos = (15,random.uniform(2,8),random.uniform(4,-10))
                if not random.random()>0.9997:
                    cC = bs.Powerup(position = pos, powerupType = random.choice(['tripleBombs','iceBombs','punch','agentHead','impactBombs','landMines','stickyBombs','shield','health','curse','luckyBlock','agentHead','stickyForce','dirt','speed','blackHole','lego','poison','agentHead','bunny','snoball','shockwave','molotov']),decorate = True,shield = False).autoRetain()
                    cC.node.extraAcceleration = (0,20,0)
                    cC.node.velocity = (random.random()*-10,random.random()*3,random.random()*3)
                else:
                    cC = portalObjects.Turret(position = pos,hasLaser = False,mute = True).autoRetain()
                    cC.node.extraAcceleration = (0,20,0)
                    cC.node.velocity = (random.random()*-10,random.random()*3,random.random()*3)
                
            bs.playMusic("Menu")
            if not bs.getEnvironment()['platform'] == 'android':
                bs.gameTimer(20,bs.Call(spawnCCube),repeat = True)
            else:
                bs.gameTimer(35,bs.Call(spawnCCube),repeat = True)
                 
        elif startEvent == 6:
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.45,0.55,0.54)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            tint = (0.5,0.5,0.5)
            self.color = (0.1,0.1,0.5)
            self.step = 0
            
            def spawnDirt():
                pos = (-15+random.random()*30,-15+random.random()*30,-15+random.random()*30)
                r = random.randint(1,9)
                if r in [1,2,3]:
                    for i in range(10 if not bs.getEnvironment()['platform'] == 'android' else 8):
                        portalObjects.Clay(position=pos,velocity = (-30+random.random()*60,-30+random.random()*60,-30+random.random()*60)).autoRetain()
                elif r == 4:
                    portalObjects.Turret(position = pos,hasLaser = False,mute = True).autoRetain()
                elif r in [5,6]:
                    import bsPowerup
                    p = bs.Powerup(powerupType = random.choice(['tripleBombs','iceBombs','punch','impactBombs','landMines','stickyBombs','shield','health','curse','luckyBlock','agentHead','stickyForce','dirt','speed','blackHole','lego','artillery']),position = pos).autoRetain()
                elif r == 7:
                    portalObjects.cCube(position = pos).autoRetain()
                elif r in [8,9]:
                    bs.Bomb(bombType = random.choice(['normal','ice','tnt','sticky']),position = pos).autoRetain()
                    
            bs.gameTimer(150 if bs.getEnvironment()['platform'] == 'android' else 250,bs.Call(spawnDirt),repeat = True)
            portalObjects.BlackHole(position=(-0.4,4,-2),scale = 3,doNotRandomize = True,infinity = True)
              
        elif startEvent == 7:
            tint = (1.14,1.1,1.0)
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.45,0.55,0.54)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            rec = 0
            self._spazArray = []
            for i in range(30 if bs.getEnvironment()['platform'] == 'android' else 15):
                s = bs.Spaz(color = (random.random(),random.random(),random.random()))
                s.node.handleMessage(bs.StandMessage(position = (random.randint(-4,4),3,random.randint(-7,1)),angle = int(random.random()*360)))
                s.node.handleMessage('celebrate',5430000)
                self._spazArray.append(s)
            def lightningBolt():
                bs.shakeCamera(5)
                groms = ['grom','grom2']
                bs.playSound(bs.getSound(random.choice(groms)))
                
                light = bs.newNode('light',
                                attrs={'position':(0,10,0),
                                    'color': (0.2,0.2,0.4),
                                    'volumeIntensityScale': 1.0,
                                    'radius':10})
                bsUtils.animate(light,"intensity",{0:1,50:10,150:5,250:0,260:10,410:5,510:0})
                
            def boom():
                lightningBolt()
                bsUtils.animateArray(bs.getSharedObject('globals'),'tint',3,{0:bs.getSharedObject('globals').tint,500:(0,0,0)})
                
            def reBoom():
                bsUtils.animateArray(bs.getSharedObject('globals'),'tint',3,{0:bs.getSharedObject('globals').tint,500:(0.4,0.4,0.5)})
                bs.getSharedObject('globals').cameraMode = 'follow'
                
                self.light = bs.newNode('light',
                            attrs={'position':(3,10,-5),
                                'color': (1.2,1.1,0.1),
                                'volumeIntensityScale': 1.0,
                                'radius':0.8,
                                'intensity':1})
                                
                bsUtils.animate(self.light,'intensity',{0:1,100:1.05,110:0.3,120:1,800:1.1,900:1,910:0.6,930:1.1,1000:1,1500:1,1510:0,1520:1,3000:0.6,3300:1,4000:1.1},True)
                
            def knockOut():
                for i in self._spazArray:
                    i.node.handleMessage('knockout',5000)
                bs.gameTimer(500,bs.Call(knockOut))
                
            def jump():
                s = int(random.random()*len(self._spazArray))
                self._spazArray[s].onJumpPress()
                self._spazArray[s].onJumpRelease()
                if not s == 40:
                    bs.gameTimer(50,bs.Call(jump))
            jump()    
            bs.gameTimer(5000,bs.Call(boom))
            bs.gameTimer(8000,bs.Call(reBoom))
            bs.gameTimer(6000,bs.Call(knockOut))
            
        elif startEvent == 8:
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.65,0.65,0.65)
            bsGlobals.vignetteInner = (1,1,1)
            tint = (0.35,0.35,0.4)

            self._background = bsUtils.Background(fadeTime=500, startFaded=True, showLogo=False)
            self._part = 1
            self._text = bsUtils.Text('',
                                      maxWidth=2000,
                                      hAlign='center',
                                      vAlign='center',
                                      position=(0,270),
                                      color=(0.5,1.0,0.5,0.18),
                                      transition='fadeIn')
                                      
            def lineGen():
                word = random.choice([' password ',' hack ',' login ',' int ',' str ',' if ',' long ',' python ',' C++ ',' math ',' matrix ',' compilation ',' array '])
                a = ''
                for i in range(90):
                    a += str(random.randint(0,1))
                ch = random.random()
                if ch>0.98:
                    a = a[8:]
                    s = random.randint(1,80)
                    a = a[s:] +  word  + a[:s-len(a)]
                return a
                                      
            def addLine():
                self._text.node.text += "\n"+lineGen()
                if len(self._text.node.text) > 8000:
                    self._text.node.text = self._text.node.text[200:]
                
                
               
            for i in range(560):
                addLine()
                
            bsUtils.animateArray(self._text.node,'position',2,{0:(0,0),10000:(0,900),20000:(0,0)},True)
                
        elif startEvent == 9:
            bs.playMusic('MindHeist')
            
            bs.screenMessage("Fire")
            tint = (0.3,0.3,0.3)
            bsGlobals.vignetteOuter = (0.9,0.9,0.9)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            def dropBGD():
                pos = (-10+(random.random()*25),3.2,-15+(random.random()*25))
                bs.emitBGDynamics(position=pos,count=int(30+random.random()*70),scale=1+random.random(),spread=15,chunkType='spark',emitType = 'stickers')
                
            bs.gameTimer(10 if bs.getEnvironment()['platform'] == 'android' else 10,dropBGD,True)
            
        elif startEvent == 10:
            self.color = (0,0,0)
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.45,0.55,0.54)
            bsGlobals.vignetteInner = (0.99,0.98,0.98)
            tint = (0.2,0.2,0.2)
            bs.playMusic("ForwardMarch")
            def dropB():
                    fwBomb = bs.Bomb(position = (-10+(random.random()*25),1,-15+(random.random()*25)),velocity=(0,100,0),bombType = 'superMine',blastRadius = 3,notShake = True)
                    fwBomb.node.extraAcceleration = (0,50+random.randint(-8,8),0)
                    def expl():
                        if fwBomb.node.exists():
                            pos = fwBomb.node.position
                            fwBomb.node.delete()
                            bs.Blast(blastType = 'normal',position = pos,blastRadius = 4, blastColor = (random.random()*2,random.random()*2,random.random()*2),notScorch = True)
                            bs.emitBGDynamics(position=pos,velocity=(0,10,0),count=random.randint(230,500),scale=0.4+random.random(),spread=0.4+random.random()*0.7,chunkType='spark')
                            bs.animateArray(bs.getSharedObject('globals'),'ambientColor',3,{0:(1.06,1.04,1.03),120:(8,8,8),280+random.randint(50,220):(1.06,1.04,1.03)})
                    bs.gameTimer(500+int(random.random()*300),bs.Call(expl))
            
            bs.gameTimer(800+int(random.random()*350),bs.Call(dropB),repeat = True)
            
        elif startEvent == 11:
            self.color = (0.2,0.1,0)
            bsGlobals.ambientColor = (1.06,1.04,1.03)
            bsGlobals.vignetteOuter = (0.7,0.7,0.7)
            bsGlobals.vignetteInner = (1.0,0.98,0.95)
            tint = (1.2,1.1,1)
            bs.screenMessage('defeat everyone!!')
            bs.playMusic('Redemption')
            self.bottom = bs.NodeActor(bs.newNode('terrain',
                                                  attrs={'model':pumpkinsBottom,
                                                         'colorTexture':pumkinsBottomTex}))

            self.pumpkins = bs.NodeActor(bs.newNode('terrain',
                                                   attrs={'model':bs.getModel('agentHead'),
                                                          'colorTexture':pumkinsTex,
                                                          'reflection':'soft',
                                                          'reflectionScale':[0.15],
                                                          'materials':[bs.getSharedObject('footingMaterial')]}))
                                                          
            self.pumpkinsInside = bs.NodeActor(bs.newNode('terrain',
                                                   attrs={'model':bs.getModel('agentHead'),
                                                          'colorTexture':pumkinsTex,
                                                          'reflection':'soft',
                                                          #'reflectionScale':[0.03],
                                                          'materials':[bs.getSharedObject('footingMaterial')]}))
            
        elif startEvent == 12:
            
            bs.playMusic('intro')
            
        
            def dropBGD():
                pos = (-15+(random.random()*30),15,-15+(random.random()*30))
                vel = ((-5.0+random.random()*30.0) * (-1.0 if pos[0] > 0 else 1.0), -50.0,random.uniform(-20,20))
                bs.emitBGDynamics(position=pos,velocity=vel,count=10,scale=1+random.random(),spread=0,chunkType='spark')
        
            bs.gameTimer(20,bs.Call(dropBGD),repeat = True)
            
            bs.screenMessage("Go")
            tint = (0.45,0.45,0.45)
            bsGlobals.vignetteOuter = (0.98,0.98,0.98)
            bsGlobals.vignetteInner = (1,1,1)
             

        if not startEvent in [4,5,6,8,11,12]:
            self.bottom = bs.NodeActor(bs.newNode('terrain',
                                                  attrs={'model':bottomModel,
                                                         'reflection':'soft',
                                                         'reflectionScale':[0.45],
                                                         'colorTexture':testColorTexture}))

            self.vrBottomFill = bs.NodeActor(bs.newNode('terrain',
                                                        attrs={'model':vrBottomFillModel,
                                                               'lighting':False,
                                                               'vrOnly':True,
                                                               'colorTexture':testColorTexture}))
            self.vrTopFill = bs.NodeActor(bs.newNode('terrain',
                                                     attrs={'model':vrTopFillModel,
                                                            'vrOnly':True,
                                                            'lighting':False,
                                                            'colorTexture':bgTex}))
            self.terrain = bs.NodeActor(bs.newNode('terrain',
                                                   attrs={'model':model,
                                                          'collideModel':collide,
                                                          'colorTexture':testColorTexture,
                                                          'reflection':'soft',
                                                          'reflectionScale':[0.3],
                                                          'materials':[bs.getSharedObject('footingMaterial')]}))

            self.trees = bs.NodeActor(bs.newNode('terrain',
                                                 attrs={'model':treesModel,
                                                        'lighting':False,
                                                        'reflection':'char',
                                                        'reflectionScale':[0.1],
                                                        'colorTexture':treesTexture}))
                                                        
              
                                                        
        if not startEvent == 5:
            self.bg = bs.NodeActor(bs.newNode('terrain',
                                              attrs={'model':bgModel,
                                                     'color':self.color,
                                                     'lighting':False,
                                                     'background':True,
                                                     'colorTexture':bgTex}))
                                                                                           
        else:                                    
            self.bg = bs.NodeActor(bs.newNode('terrain',
                                              attrs={'model':bs.getModel('agentHead'),
                                                     'color':self.color,
                                                     'lighting':False,
                                                     'background':True,
                                                     'colorTexture':bs.getTexture('agentHead')}))
                                                 
        textOffsetV = 0
        self._ts = 0.86

        self._language = None
        self._updateTimer = bs.Timer(1000, self._update, repeat=True)
        self._update()

        # hopefully this won't hitch but lets space these out anyway..
        bsInternal._addCleanFrameCallback(bs.WeakCall(self._startPreloads))

        random.seed()
        # bring up the last place we were at, or start at the main menu otherwise
        with bs.Context('UI'):
            try: mainWindow = bsUI.gMainWindow
            except Exception: mainWindow = None

            # when coming back from a kiosk-mode game, jump to the kiosk start screen..
            if bsUtils.gRunningKioskModeGame:
                bsUI.uiGlobals['mainMenuWindow'] = bsUI.KioskWindow().getRootWidget()
            # ..or in normal cases go back to the main menu
            else:
                if mainWindow == 'Gather': bsUI.uiGlobals['mainMenuWindow'] = bsUI.GatherWindow(transition=None).getRootWidget()
                elif mainWindow == 'Watch': bsUI.uiGlobals['mainMenuWindow'] = bsUI.WatchWindow(transition=None).getRootWidget()
                elif mainWindow == 'Team Game Select': bsUI.uiGlobals['mainMenuWindow'] = bsUI.TeamsWindow(sessionType=bs.TeamsSession,transition=None).getRootWidget()
                elif mainWindow == 'Free-for-All Game Select': bsUI.uiGlobals['mainMenuWindow'] = bsUI.TeamsWindow(sessionType=bs.FreeForAllSession,transition=None).getRootWidget()
                elif mainWindow == 'Coop Select': bsUI.uiGlobals['mainMenuWindow'] = bsUI.CoopWindow(transition=None).getRootWidget()
                else: bsUI.uiGlobals['mainMenuWindow'] = bsUI.MainMenuWindow(transition=None).getRootWidget()

                # attempt to show any pending offers immediately.  If that doesn't work, try again in a few seconds (we may not have heard back from the server)
                # ..if that doesn't work they'll just have to wait until the next opportunity.
                if not bsUI._showOffer():
                    def tryAgain():
                        if not bsUI._showOffer():
                            bs.realTimer(2000,bsUI._showOffer) # try one last time..
                    bs.realTimer(2000,tryAgain)
            
        gDidInitialTransition = True
        
        
    def _update(self):
        # update logo in case it changes..
        if self._logoNode is not None and self._logoNode.exists():
            customTexture = self._getCustomLogoTexName()
            if customTexture != self._customLogoTexName:
                self._customLogoTexName = customTexture
                self._logoNode.texture = bs.getTexture(customTexture if customTexture is not None else 'logo')
                self._logoNode.modelOpaque = None if customTexture is not None else bs.getModel('logo')
                self._logoNode.modelTransparent = None if customTexture is not None else bs.getModel('logoTransparent')
        
        # if language has changed, recreate our logo text/graphics
        l = bs.getLanguage()
        if l != self._language:
            self._language = l

            env = bs.getEnvironment()
            
            y = 20
            gScale = 1.1
            self._wordActors = []
            baseDelay = 1000
            delay = baseDelay
            delayInc = 20

            # come on faster after the first time
            if gDidInitialTransition:
                baseDelay = 0
                delay = baseDelay
                delayInc = 20

                
            # we draw higher in kiosk mode (make sure to test this when making adjustments)
            # for now we're hard-coded for a few languages.. should maybe look into generalizing this?..
            if bs.getLanguage() == 'Chinese':
                baseX = -270
                x = baseX-20
                spacing = 85*gScale
                yExtra = 80 if env['kioskMode'] else 0

                
                self._makeLogo(x-110+50,113+y+1.2*yExtra,0.34*gScale,delay=baseDelay+100,customTexture='chTitleChar1',jitterScale=2.0,vrDepthOffset=-30)
                
                x += spacing; delay += delayInc
                self._makeLogo(x-10+50,110+y+1.2*yExtra,0.31*gScale,delay=baseDelay+150,customTexture='chTitleChar2',jitterScale=2.0,vrDepthOffset=-30)
                x += 2.0 * spacing; delay += delayInc
                
                self._makeLogo(x+180-140,110+y+1.2*yExtra,0.3*gScale,delay=baseDelay+250,customTexture='chTitleChar3',jitterScale=2.0,vrDepthOffset=-30)
                x += spacing; delay += delayInc
                self._makeLogo(x+241-120,110+y+1.2*yExtra,0.31*gScale,delay=baseDelay+300,customTexture='chTitleChar4',jitterScale=2.0,vrDepthOffset=-30)
                x += spacing; delay += delayInc
                self._makeLogo(x+300-90,105+y+1.2*yExtra,0.34*gScale,delay=baseDelay+350,customTexture='chTitleChar5',jitterScale=2.0,vrDepthOffset=-30)
                
                self._makeLogo(baseX+155, 146+y+1.2*yExtra, 0.28*gScale, delay=baseDelay+200, rotate=-7)
                
            else:
                baseX = -170
                x = baseX-20
                spacing = 55*gScale
                yExtra = 80 if env['kioskMode'] else 0

                x1 = x
                delay1 = delay
                for shadow in (True, False):
                    x = x1
                    delay = delay1
                    self._makeWord('B',x-50,y-23+0.8*yExtra,scale=1.3*gScale,delay=delay,vrDepthOffset=3,shadow=shadow)
                    x += spacing; delay += delayInc
                    self._makeWord('m',x,y+yExtra,delay=delay,scale=gScale,shadow=shadow)
                    x += spacing*1.25; delay += delayInc
                    self._makeWord('b',x,y+yExtra,delay=delay,scale=gScale,vrDepthOffset=5,shadow=shadow)
                    x += spacing*0.85; delay += delayInc

                    self._makeWord('S',x,y-23+0.8*yExtra,scale=1.3*gScale,delay=delay,vrDepthOffset=14,shadow=shadow)
                    x += spacing; delay += delayInc
                    self._makeWord('q',x,y+yExtra,delay=delay,scale=gScale,shadow=shadow)
                    x += spacing*0.9; delay += delayInc
                    self._makeWord('u',x,y+yExtra,delay=delay,scale=gScale,vrDepthOffset=7,shadow=shadow)
                    x += spacing*0.9; delay += delayInc
                    #print random.random()
                    self._makeWord('o' if random.random() > 0.999 else 'a',x,y+yExtra,delay=delay,scale=gScale,shadow=shadow)
                    x += spacing*0.95; delay += delayInc
                    self._makeWord('d',x,y+yExtra,delay=delay,scale=gScale,vrDepthOffset=6,shadow=shadow)

                self._makeLogo(baseX-28,125+y+1.2*yExtra,0.32*gScale,delay=baseDelay)

                

    def _makeWord(self, word, x, y, scale=1.0, delay=0, vrDepthOffset=0, shadow=False):
        if shadow:
            wordShadowObj = bs.NodeActor(bs.newNode('text',
                                                    attrs={'position':(x,y),
                                                           'big':True,
                                                           'color':(0.0,0.0,0.2,0.08),
                                                           'tiltTranslate':0.09,
                                                           'opacityScalesShadow':False,
                                                           'shadow':0.2,
                                                           'vrDepth':-130,
                                                           'vAlign':'center',
                                                           'projectScale':0.97*scale,
                                                           'scale':1.0,
                                                           'text':word}))
            self._wordActors.append(wordShadowObj)
        else:
            wordObj = bs.NodeActor(bs.newNode('text',
                                              attrs={'position':(x,y),
                                                     'big':True,
                                                     'color':(1.2,1.15,1.15,1.0),
                                                     'tiltTranslate':0.11,
                                                     'shadow':0.2,
                                                     'vrDepth':-40+vrDepthOffset,
                                                     'vAlign':'center',
                                                     'projectScale':scale,
                                                     'scale':1.0,
                                                     'text':word}))
            self._wordActors.append(wordObj)


        # add a bit of stop-motion-y jitter to the logo
        # (unless we're in VR mode in which case its best to leave things still)
        if not bs.getEnvironment()['vrMode']:
            if not shadow: c = bs.newNode("combine",owner=wordObj.node,attrs={'size':2})
            else: c = None
            if shadow: c2 = bs.newNode("combine",owner=wordShadowObj.node,attrs={'size':2})
            else: c2 = None
                
            if not shadow:
                c.connectAttr('output',wordObj.node,'position')
            if shadow:
                c2.connectAttr('output',wordShadowObj.node,'position')
            keys = {}
            keys2 = {}
            timeV = 0
            for i in range(10):
                val = x+(random.random()-0.5)*0.8
                val2 = x+(random.random()-0.5)*0.8
                keys[timeV*self._ts] = val
                keys2[timeV*self._ts] = val2+5
                timeV += random.random() * 100
            if c is not None: bs.animate(c,"input0",keys,loop=True)
            if c2 is not None: bs.animate(c2,"input0",keys2,loop=True)
            keys = {}
            keys2 = {}
            timeV = 0
            for i in range(10):
                val = y+(random.random()-0.5)*0.8
                val2 = y+(random.random()-0.5)*0.8
                keys[timeV*self._ts] = val
                keys2[timeV*self._ts] = val2-9
                timeV += random.random() * 100
            if c is not None: bs.animate(c,"input1",keys,loop=True)
            if c2 is not None: bs.animate(c2,"input1",keys2,loop=True)

        if not shadow:
            bs.animate(wordObj.node,"projectScale",{delay:0.0, delay+100:scale*1.1, delay+200:scale})
        else:
            bs.animate(wordShadowObj.node,"projectScale",{delay:0.0, delay+100:scale*1.1, delay+200:scale})

    def _getCustomLogoTexName(self):
        if bsInternal._getAccountMiscReadVal('easter',False):
            return 'logoEaster'
        elif firstApril:
            return 'logoLegacy' if not JRMPmode else 'logoBS'
        else:
            return None
                
        
    # pop the logo and menu in
    def _makeLogo(self, x, y, scale, delay, customTexture=None, jitterScale=1.0, rotate=0, vrDepthOffset=0):
        # temp easter googness
        if customTexture is None:
            customTexture = self._getCustomLogoTexName()
        self._customLogoTexName = customTexture
        logo = bs.NodeActor(bs.newNode('image',
                                             attrs={'texture': bs.getTexture(customTexture if customTexture is not None else 'logo'),
                                                    #'modelOpaque':None if customTexture is not None else bs.getModel('agentHead'),
                                                    #'modelTransparent':None if customTexture is not None else bs.getModel('logoTransparent'),
                                                    'vrDepth':-10+vrDepthOffset,
                                                    'rotate':rotate,
                                                    'attach':"center",
                                                    'tiltTranslate':0.21,
                                                    'absoluteScale':True}))
        self._logoNode = logo.node
        self._wordActors.append(logo)

        # add a bit of stop-motion-y jitter to the logo
        # (unless we're in VR mode in which case its best to leave things still)
        if not bs.getEnvironment()['vrMode']:
            c = bs.newNode("combine",owner=logo.node,attrs={'size':2})
            c.connectAttr('output',logo.node,'position')

            keys = {}
            timeV = 0
            # gen some random keys for that stop-motion-y look
            for i in range(10):
                keys[timeV] = x+(random.random()-0.5)*0.7*jitterScale
                timeV += random.random() * 100
            bs.animate(c,"input0",keys,loop=True)
            keys = {}
            timeV = 0
            for i in range(10):
                keys[timeV*self._ts] = y+(random.random()-0.5)*0.7*jitterScale
                timeV += random.random() * 100
            bs.animate(c,"input1",keys,loop=True)
        else:
            logo.node.position = (x,y)

        c = bs.newNode("combine",owner=logo.node,attrs={"size":2})

        keys = {delay:0,delay+100:700*scale,delay+200:600*scale}
        bs.animate(c,"input0",keys)
        bs.animate(c,"input1",keys)
        c.connectAttr("output",logo.node,"scale")
            
    def _startPreloads(self):
        # FIXME - the func that calls us back doesn't save/restore state
        # or check for a dead activity so we have to do that ourself..
        if self.isFinalized(): return
        with bs.Context(self): _preload1()

        #bs.gameTimer(500,lambda: bs.playMusic('Menu'))
        
        
# a second or two into the main menu is a good time to preload some stuff we'll need elsewhere
# to avoid hitches later on..
def _preload1():
    for m in ['plasticEyesTransparent','playerLineup1Transparent','playerLineup2Transparent',
              'playerLineup3Transparent','playerLineup4Transparent','angryComputerTransparent',
              'scrollWidgetShort','windowBGBlotch']: bs.getModel(m)
    for t in ["playerLineup","lock"]: bs.getTexture(t)
    for tex in ['iconRunaround','iconOnslaught',
                'medalComplete','medalBronze','medalSilver',
                'medalGold','characterIconMask']: bs.getTexture(tex)

    bs.getTexture("bg")

    bs.Powerup.getFactory()

    bs.gameTimer(100,_preload2)

def _preload2():

    # FIXME - could integrate these loads with the classes that use them
    # so they don't have to redundantly call the load (even if the actual result is cached)
    for m in ["powerup","powerupSimple"]: bs.getModel(m)
    for t in ["powerupBomb","powerupSpeed","powerupPunch",
              "powerupIceBombs","powerupStickyBombs","powerupShield",
              "powerupImpactBombs","powerupHealth"]: bs.getTexture(t)
    for s in ["powerup01","boxDrop","boxingBell","scoreHit01",
              "scoreHit02","dripity","spawn","gong"]: bs.getSound(s)

    bs.Bomb.getFactory()

    bs.gameTimer(100,_preload3)

def _preload3():

    for m in ["bomb","bombSticky","impactBomb"]: bs.getModel(m)
    for t in ["bombColor","bombColorIce","bombStickyColor",
              "impactBombColor","impactBombColorLit"]: bs.getTexture(t)
    for s in ["freeze","fuse01","activateBeep","warnBeep","grom","groza"]: bs.getSound(s)

    spazFactory = bs.Spaz.getFactory()

    # go through and load our existing spazzes
    # (spread these out quite a bit)
    def _load(spaz):
        spazFactory._preload(spaz)
        # icons also..
        bs.getTexture(bsSpaz.appearances[spaz].iconTexture)
        bs.getTexture(bsSpaz.appearances[spaz].iconMaskTexture)

    # FIXME - need to come up with a standin texture mechanism or something
    # ..preloading won't scale too much farther..
    t = 50
    # for spaz in bsSpaz.appearances:
    #     bs.gameTimer(t,bs.Call(_load,spaz))
    #     t += 100

    bs.gameTimer(200,_preload4)


def _preload4():
    for t in ['bar','meter',
              'null','flagColor','achievementOutline']: bs.getTexture(t)
    for m in ['frameInset','meterTransparent','achievementOutline']: bs.getModel(m)
    for s in ['metalHit','metalSkid','refWhistle','achievement']: bs.getSound(s)

    bs.Flag.getFactory()
    bs.Powerup.getFactory()       
        
class BDSplashScreenActivity(bs.Activity):

    def __init__(self,settings={}):
        bs.Activity.__init__(self,settings)
        self._part1Duration = 2000
        self.loadingStep = 0
        
    def _startPreloads(self):
        return
        
    def onTransitionIn(self):
        import bsInternal
        bs.Activity.onTransitionIn(self)
        bsInternal._addCleanFrameCallback(bs.WeakCall(self._startPreloads))
        self._background = bsUtils.Background(fadeTime=500, startFaded=True, showLogo=False)
        self._part = 1
        self._text = bsUtils.Text(bs.Lstr(resource='loadingM'),
                                  maxWidth=2000,
                                  hAlign='center',
                                  vAlign='center',
                                  position=(0,260),
                                  color=(1,1,1,1),
                                  transition='fadeIn')
                                  
                                  
        self._text2 = bsUtils.Text(bs.Lstr(resource='ifbug'),
                                  maxWidth=2000,
                                  hAlign='center',
                                  vAlign='center',
                                  position=(0,-200),
                                  color=(1,1,1,1),
                                  transition='fadeIn')


        self._logoImage = bsUtils.Image(texture = bs.getTexture('logo'),position=(0,0),transition=None,transitionDelay=0,attach='center',
                                        color=(1,1,1,1),scale=(200,200),transitionOutDelay=None,modelOpaque=None,modelTransparent=None,
                                        vrDepth=0,hostOnly=False,front=False)
                                        
        bsUtils.animateArray(self._logoImage.node,'scale',2,{0:(0,0),300:(230,230),400:(200,200)})
        
        self.bar = []
        m = 4.55
        i = -50*m
        
        while i<50*m:
            self._barImage = bsUtils.Image(texture = bs.getTexture('buttonSquare'),position=(i,200),transition=None,transitionDelay=0,attach='center',
                                            color=(1,1,1,1),scale=(50,50),transitionOutDelay=None,modelOpaque=None,modelTransparent=None,
                                            vrDepth=0,hostOnly=False,front=False)
                                            
            bsUtils.animateArray(self._barImage.node,'scale',2,{0:(0,0),300:(50,50)})
            bsUtils.animate(self._barImage.node,'rotate',{0:0,300:360})
            self.bar.append(self._barImage)
            i += 10*m
        bs.gameTimer(50,self.recursiya)
            
    def recursiya(self):
        speed = 100
        self.bar[self.loadingStep].node.color = (0,1.5,0,1)
        self.loadingStep += 1
        
        if self.loadingStep == 1:
            bs.gameTimer((self._part1Duration/speed)+(300-80), self.recursiya)
            # +(300-80) is little delay for animation.
        elif self.loadingStep == 2:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 3:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 4:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 5:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
            bsInternal._setPartyIconAlwaysVisible(True)
        elif self.loadingStep == 6:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 7:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 8:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 9:
            bs.gameTimer((self._part1Duration/speed), self.recursiya)
        elif self.loadingStep == 10:
            bs.gameTimer(10, self.end)
               
gFirstRun = True

class MainMenuSession(bs.Session):

    def __init__(self):
        bs.Session.__init__(self)

        self._locked = False
        
        env = bs.getEnvironment()
        global gFirstRun
        if False:
            gFirstRun = False
            self.setActivity(bs.newActivity(BDSplashScreenActivity))
        else:
            self.setActivity(bs.newActivity(MainMenuActivity))

    def onActivityEnd(self,activity,results):
        if self._locked:
            bsInternal._unlockAllInput()
        # any ending activity leads us into the main menu one..
        self.setActivity(bs.newActivity(MainMenuActivity))
        
    def onPlayerRequest(self,player):
        # reject player requests, but if we're in a splash-screen, take the opportunity to tell it to leave
        # FIXME - should add a blanket way to capture all input for cases like this
        activity = self.getActivity()
        if isinstance(activity, SplashScreenActivity):
            with bs.Context(activity): activity.onSomethingPressed()
            
        return False

