import bs
import bsUtils
from bsVector import Vector
import random
import portalObjects
import weakref


class BombFactory(object):
    """
        I fucked to rewind this description in script and deleted it.
    """

    def getRandomExplodeSound(self):
        'Return a random explosion bs.Sound from the factory.'
        return self.explodeSounds[random.randrange(len(self.explodeSounds))]

    def __init__(self):
        """
        Instantiate a BombFactory.
        You shouldn't need to do this; call bs.Bomb.getFactory() to get a shared instance.
        """

        self.bombModel = bs.getModel('pixelHead')
        self.stickyBombModel = bs.getModel('zoeHead')
        self.impactBombModel = bs.getModel('ninjaHead')
        self.landMineModel = bs.getModel('landMine')
        self.tntModel = bs.getModel('egg')
        self.toxicModel = bs.getModel('agentHead')
        self.poisonModel = bs.getModel('bonesHead')
        self.foxicModel = bs.getModel('cyborgHead')        
        self.slipperModel = bs.getModel('agentHead')
        self.dirtModel = bs.getModel("santaHead")
        self.bananaModel = bs.getModel('agentHead')
        self.shockWaveModel = bs.getModel('bomb')
        self.petardModel = bs.getModel('agentHead')
        self.superMineModel = bs.getModel('landMine')        
        self.fireBottleModel = bs.getModel('agentHead')
        self.waterFireModel = bs.getModel('bomb')        

        self.regularTex = bs.getTexture('achievementBoxer')
        self.iceTex = bs.getTexture('bombColorIce')
        self.stickyTex = bs.getTexture('bombStickyColor')
        self.forceTex = bs.getTexture('egg2')
        self.impactTex = bs.getTexture('impactBombColor')
        self.impactLitTex = bs.getTexture('impactBombColorLit')
        self.landMineTex = bs.getTexture('landMine')
        self.landMineLitTex = bs.getTexture('landMineLit')
        self.superMineTex = bs.getTexture('achievementCrossHair')
        self.superMineLitTex = bs.getTexture('circleNoAlpha')        
        self.tntTex = bs.getTexture('tnt')
        self.toxicTex = bs.getTexture('aliIcon')
        self.poisonTex = bs.getTexture("powerupCurse")
        self.foxicTex = bs.getTexture("cyborgColor")        
        self.slipperTex = bs.getTexture('agentHead')
        self.dirtTex = bs.getTexture("santaColor")
        self.bananaTex = bs.getTexture('agentHead')
        self.shockWaveTex = bs.getTexture("aliIcon")
        self.petardTex = bs.getTexture('agentHead')
        self.fireBottleTex = bs.getTexture('agentHead')
        self.waterFireTex = bs.getTexture('achievementInControl')        

        self.hissSound = bs.getSound('hiss')
        self.debrisFallSound = bs.getSound('debrisFall')
        self.woodDebrisFallSound = bs.getSound('woodDebrisFall')

        self.explodeSounds = (bs.getSound('explosion01'),
                              bs.getSound('explosion02'),
                              bs.getSound('explosion03'),
                              bs.getSound('explosion04'),
                              bs.getSound('explosion05'))

        self.freezeSound = bs.getSound('freeze')
        self.fuseSound = bs.getSound('fuse01')
        self.activateSound = bs.getSound('activateBeep')
        self.warnSound = bs.getSound('warnBeep')
        self.toxicSound = bs.getSound("metall")
        self.foxicSound = bs.getSound("metall")        
        self.poisonSound = bs.getSound("poisonBreak")
        self.shockWaveSound = bs.getSound("shockwaveImpact")

        # set up our material so new bombs dont collide with objects
        # that they are initially overlapping
        self.bombMaterial = bs.Material()
        self.normalSoundMaterial = bs.Material()
        self.stickyMaterial = bs.Material()

        self.bombMaterial.addActions(
            conditions=((('weAreYoungerThan',100),'or',('theyAreYoungerThan',100)),
                        'and',('theyHaveMaterial',bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision','collide',False)))

        # we want pickup materials to always hit us even if we're currently not
        # colliding with their node (generally due to the above rule)
        self.bombMaterial.addActions(
            conditions=('theyHaveMaterial',bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision','useNodeCollide',False)))
            #addActions(('message','theirNode','atConnect',bs.DieMessage()))
        
        self.bombMaterial.addActions(actions=('modifyPartCollision','friction',0.3))

        self.landMineNoExplodeMaterial = bs.Material()
        self.landMineBlastMaterial = bs.Material()
        self.landMineBlastMaterial.addActions(
            conditions=(('weAreOlderThan',200),
                        'and',('theyAreOlderThan',200),
                        'and',('evalColliding',),
                        'and',(('theyDontHaveMaterial',self.landMineNoExplodeMaterial),
                               'and',(('theyHaveMaterial',bs.getSharedObject('objectMaterial')),
                                      'or',('theyHaveMaterial',bs.getSharedObject('playerMaterial'))))),
            actions=(('message','ourNode','atConnect',ImpactMessage())))
            
            
        self.forseBombMaterial = bs.Material()
        self.forseBombMaterial.addActions(
            conditions=(('weAreOlderThan',200),
                        'and',('theyAreOlderThan',200),
                        'and',('evalColliding',),
                        'and',(('theyDontHaveMaterial',self.landMineNoExplodeMaterial),
                               'and',(('theyHaveMaterial',bs.getSharedObject('objectMaterial')),
                                      'or',('theyHaveMaterial',bs.getSharedObject('playerMaterial'))))),
            actions=(('message','ourNode','atConnect',SetStickyMessage())))

        
        self.impactBlastMaterial = bs.Material()
        self.impactBlastMaterial.addActions(
            conditions=(('weAreOlderThan',200),
                        'and',('theyAreOlderThan',200),
                        'and',('evalColliding',),
                        'and',(('theyHaveMaterial',bs.getSharedObject('footingMaterial')),
                               'or',('theyHaveMaterial',bs.getSharedObject('objectMaterial')))),
            actions=(('message','ourNode','atConnect',ImpactMessage())))
        

        self.blastMaterial = bs.Material()
        self.blastMaterial.addActions(
            conditions=(('theyHaveMaterial',bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',ExplodeHitMessage())))
                     
        self.healthMaterial = bs.Material()
        self.healthMaterial.addActions(
            conditions=(('theyHaveMaterial',bs.getSharedObject('objectMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','ourNode','atConnect',HealthMessage())))
        self.healthMaterial.addActions(
            conditions=(('theyHaveMaterial',bs.getSharedObject('dirtMaterial'))),
            actions=(('modifyPartCollision','collide',True),
                     ('modifyPartCollision','physical',False),
                     ('message','theirNode','atConnect',bs.DieMessage())))
                     

        self.dinkSounds = (bs.getSound('bombDrop01'),
                           bs.getSound('bombDrop02'))
        self.stickyImpactSound = bs.getSound('stickyImpact')

        self.rollSound = bs.getSound('bombRoll01')

        # collision sounds
        self.normalSoundMaterial.addActions(
            conditions=('theyHaveMaterial',bs.getSharedObject('footingMaterial')),
            actions=(('impactSound',self.dinkSounds,2,0.8),
                     ('rollSound',self.rollSound,3,6)))

        self.stickyMaterial.addActions(
            actions=(('modifyPartCollision','stiffness',0.1),
                     ('modifyPartCollision','damping',1.0)))

        self.stickyMaterial.addActions(
            conditions=(('theyHaveMaterial',bs.getSharedObject('playerMaterial')),'or',('theyHaveMaterial',bs.getSharedObject('footingMaterial'))),
            actions=(('message','ourNode','atConnect',SplatMessage())))

class SplatMessage(object):
    pass

class ExplodeMessage(object):
    pass

class ImpactMessage(object):
    """ impact bomb touched something """
    pass
    
class SetStickyMessage(object):
    pass

class ArmMessage(object):
    pass

class WarnMessage(object):
    pass

class ExplodeHitMessage(object):
    "Message saying an object was hit"
    def __init__(self):
        pass
        
class HealthMessage(object):
    def __init__(self):
        pass

class Blast(bs.Actor):
    """
    category: Game Flow Classes

    An explosion, as generated by a bs.Bomb.
    """
    def __init__(self,position=(0,1,0),velocity=(0,0,0),blastRadius=2.0,blastType="normal",sourcePlayer=None,hitType='explosion',hitSubType='normal',blastColor = (1,0.3,0.1),notShake = False,notScorch = False):
        """
        Instantiate with given values.
        """
        bs.Actor.__init__(self)

        
        factory = Bomb.getFactory()

        self.blastType = blastType
        self.sourcePlayer = sourcePlayer

        self.hitType = hitType;
        self.hitSubType = hitSubType;

        # blast radius
        self.radius = blastRadius
        
        ms = factory.healthMaterial if self.blastType == 'heal' else factory.blastMaterial
        
        self.node = bs.newNode('region',
                               attrs={'position':(position[0],position[1]-0.1,position[2]), # move down a bit so we throw more stuff upward
                                      'scale':(self.radius,self.radius,self.radius),
                                      'type':'sphere',
                                      'materials':(ms,bs.getSharedObject('attackMaterial'))},
                               delegate=self)

        bs.gameTimer(50,self.node.delete)

        # throw in an explosion and flash
        explosion = bs.newNode("explosion",
                               attrs={'position':position,
                                      'velocity':(velocity[0],max(-1.0,velocity[1]),velocity[2]),
                                      'radius':self.radius if not self.blastType == 'agentHead' else 0.4,
                                      'big':(self.blastType in ['tnt','agentHead','shockWave','agentHead'])})
                                      
        if self.blastType == "ice":
            explosion.color = (0,0.05,0.4)
        elif self.blastType == 'agentHead':
            explosion.color = (0.5,0,0)
        elif self.blastType == 'shockWave':
            explosion.color = (0.3,0.3,1)
        elif self.blastType == 'heal':
            explosion.color = (0.6,0.3,0.3)
        elif self.blastType == 'agentHead':
            explosion.color = (1,1,0)
        elif self.blastType == 'agentHead':
            explosion.color = (0.1,1,0.3)
        else:
            explosion.color = blastColor

        bs.gameTimer(1000,explosion.delete)

        if not self.blastType in ['agentHead','heal','shockWave']:
            if self.blastType != 'ice': bs.emitBGDynamics(position=position,velocity=velocity,count=int(1.0+random.random()*4),emitType='tendrils',tendrilType='thinSmoke')
            bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*4),emitType='tendrils',tendrilType='ice' if self.blastType == 'ice' else 'smoke')
            bs.emitBGDynamics(position=position,emitType='distortion',spread=2.0 if self.blastType == 'tnt' else 1.0)

        # and emit some shrapnel..
        if self.blastType == 'ice':
            def _doEmit():
                bs.emitBGDynamics(position=position,velocity=velocity,count=30,spread=2.0,scale=0.4,chunkType='ice',emitType='stickers');
            bs.gameTimer(50,_doEmit) # looks better if we delay a bit


        elif self.blastType == 'sticky':
            def _doEmit():
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),spread=0.7,chunkType='slime');
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),scale=0.5, spread=0.7,chunkType='slime');
                bs.emitBGDynamics(position=position,velocity=velocity,count=15,scale=0.6,chunkType='slime',emitType='stickers');
                bs.emitBGDynamics(position=position,velocity=velocity,count=20,scale=0.7,chunkType='spark',emitType='stickers');
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(6.0+random.random()*12),scale=0.8,spread=1.5,chunkType='spark');
            bs.gameTimer(50,_doEmit)

        elif self.blastType == 'impact':
            def _doEmit():
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),scale=0.8,chunkType='metal');
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),scale=0.4,chunkType='metal');
                bs.emitBGDynamics(position=position,velocity=velocity,count=20,scale=0.7,chunkType='spark',emitType='stickers');
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(8.0+random.random()*15),scale=0.8,spread=1.5,chunkType='spark');
            bs.gameTimer(50,_doEmit) # looks better if we delay a bit
            
        elif self.blastType == 'shockWave':
            def _doEmit():
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),scale=0.8,chunkType='metal');
                bs.emitBGDynamics(position=position,velocity=velocity,count=20,scale=0.7,chunkType='spark',emitType='stickers');
                f = bs.newNode("flash",
                                   attrs={'position':position,
                                          'size':0.5,
                                          'color':(0.6,0.6,1-random.random()*0.2)})
                bs.gameTimer(60,f.delete)
            bs.gameTimer(50,_doEmit)
            
        elif self.blastType == 'agentHead':
            bs.emitBGDynamics(position=position,count=50,emitType='tendrils',tendrilType='smoke')
            
        elif self.blastType == 'dirtBomb':
            def _doEmit():
                for i in xrange(80):
                    portalObjects.Clay(
                        position=(position[0]-1+random.random()*2,
                                  position[1]+random.random(),
                                  position[2]-1+random.random()*2),
                        velocity=(-2+random.random()*4,
                                  -2+random.random()*4,
                                  -2+random.random()*4),
                        bomb=True).autoRetain()

            bs.gameTimer(10, _doEmit)
            
        elif self.blastType == 'agentHead':
            def _doEmit():
                import portalObjects
                for i in range(10): portalObjects.Clay(position = (position[0]-1+random.random()*2,position[1]+random.random(),position[2]-1+random.random()*2),velocity = (-2+random.random()*4,-2+random.random()*4,-2+random.random()*4),bomb = True,banana = True).autoRetain()
                bs.emitBGDynamics(position=position,velocity=velocity,count=1000,scale=2.5,chunkType='sweat',emitType='stickers');
            bs.gameTimer(15,_doEmit)
            
        elif self.blastType == 'agentHead':
            pass
            
        elif self.blastType == 'heal':
            pass
            

        else: # regular or land mine bomb shrapnel
            def _doEmit():
                if self.blastType != 'tnt':
                    bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),chunkType='rock');
                    bs.emitBGDynamics(position=position,velocity=velocity,count=int(4.0+random.random()*8),scale=0.5,chunkType='rock');
                bs.emitBGDynamics(position=position,velocity=velocity,count=30,scale=1.0 if self.blastType=='tnt' else 0.7,chunkType='spark',emitType='stickers');
                bs.emitBGDynamics(position=position,velocity=velocity,count=int(18.0+random.random()*20),scale=1.0 if self.blastType == 'tnt' else 0.8,spread=1.5,chunkType='spark');

                # tnt throws splintery chunks
                if self.blastType == 'tnt':
                    def _emitSplinters():
                        bs.emitBGDynamics(position=position,velocity=velocity,count=int(20.0+random.random()*25),scale=0.8,spread=1.0,chunkType='splinter');
                    bs.gameTimer(10,_emitSplinters)
                
                # every now and then do a sparky one
                if self.blastType == 'tnt' or random.random() < 0.1:
                    def _emitExtraSparks():
                        bs.emitBGDynamics(position=position,velocity=velocity,count=int(10.0+random.random()*20),scale=0.8,spread=1.5,chunkType='spark');
                    bs.gameTimer(20,_emitExtraSparks)
                        
            bs.gameTimer(50,_doEmit) # looks better if we delay a bit

        if not self.blastType == 'agentHead':
            if self.blastType == "ice":
                color = (0,0.05,0.4)
            elif self.blastType == 'agentHead':
                color = (0.5,0,0)
            elif self.blastType == 'shockWave':
                color = (0.3,0.3,1)
            elif self.blastType == 'heal':
                color = (0.6,0.3,0.3)
            elif self.blastType == 'agentHead':
                color = (1,1,0)
            elif self.blastType == 'agentHead':
                color = (0.1,1,0.3)
            else:
                color = blastColor
            light = bs.newNode('light',
                            attrs={'position':position,
                                    'color':color,
                                    'volumeIntensityScale': 10.0})
        else:
            light = bs.newNode('light',
                            attrs={'position':position,
                                    'color': (0.4,0,0),
                                    'volumeIntensityScale': 10.0})

        s = random.uniform(0.6,0.9)
        scorchRadius = lightRadius = self.radius
        if self.blastType == 'tnt':
            lightRadius *= 1.4
            scorchRadius *= 1.15
            s *= 3.0
        elif self.blastType == 'agentHead':
            lightRadius *= 0.05
            scorchRadius *= 0.05
            s *= 0.05
        elif self.blastType == 'agentHead':
            s *= 3.0

        iScale = 1.6
        bsUtils.animate(light,"intensity",{0:2.0*iScale, int(s*20):0.1*iScale, int(s*25):0.2*iScale, int(s*50):17.0*iScale, int(s*60):5.0*iScale, int(s*80):4.0*iScale, int(s*200):0.6*iScale, int(s*2000):0.00*iScale, int(s*3000):0.0})
        bsUtils.animate(light,"radius",{0:lightRadius*0.2, int(s*50):lightRadius*0.55, int(s*100):lightRadius*0.3, int(s*300):lightRadius*0.15, int(s*1000):lightRadius*0.05})
        bs.gameTimer(int(s*3000),light.delete)

        # make a scorch that fades over time
        if not self.blastType in ['heal','shockWave','agentHead'] and not notScorch:
            scorch = bs.newNode('scorch',
                                attrs={'position':position,'size':scorchRadius*0.5,'big':(self.blastType == 'tnt')})
            if self.blastType == 'ice':
                scorch.color = (1,1,1.5)
            elif self.blastType == 'agentHead':
                scorch.color = (1,1,0)
            else:
                scorch.color = (random.random(),random.random(),random.random())

            bsUtils.animate(scorch,"presence",{3000:1, 23000:0})
            bs.gameTimer(23000,scorch.delete)

        if self.blastType == 'ice':
            bs.playSound(factory.hissSound,position=light.position)
            
            
            
        p = light.position
        if not self.blastType == 'agentHead' and not self.blastType == 'heal':
            bs.playSound(factory.getRandomExplodeSound(),position=p)
            bs.playSound(factory.debrisFallSound,position=p)
        elif self.blastType == 'heal':
            bs.playSound(bs.getSound('healthBomb'),position=p)
        
        if not notShake:
            if self.blastType == 'tnt':
                bs.shakeCamera(intensity=5.0)
            elif self.blastType == 'agentHead':
                bs.shakeCamera(intensity=0.0)
            elif self.blastType == 'agentHead':
                bs.shakeCamera(intensity=0.0)
            else:
                bs.shakeCamera(intensity=1.0)

        # tnt is more epic..
        if self.blastType == 'tnt':
            bs.playSound(factory.getRandomExplodeSound(),position=p)
            def _extraBoom():
                bs.playSound(factory.getRandomExplodeSound(),position=p)
            bs.gameTimer(250,_extraBoom)
            def _extraDebrisSound():
                bs.playSound(factory.debrisFallSound,position=p)
                bs.playSound(factory.woodDebrisFallSound,position=p)
            bs.gameTimer(400,_extraDebrisSound)

    def handleMessage(self,m):
        self._handleMessageSanityCheck()
        
        if isinstance(m,bs.DieMessage):
            self.node.delete()

        elif isinstance(m,ExplodeHitMessage):
            node = bs.getCollisionInfo("opposingNode")
            if node is not None and node.exists():
                t = self.node.position

                # new
                mag = 2000.0
                if self.blastType == 'ice': mag *= 0.5
                elif self.blastType == 'landMine': mag *= 2.5
                elif self.blastType == 'tnt': mag *= 2.0
                elif self.blastType == 'superMine': mag *= 1.0  

                node.handleMessage(bs.HitMessage(pos=t,
                                                 velocity=(0,0,0),
                                                 magnitude=mag,
                                                 hitType=self.hitType,
                                                 hitSubType=self.hitSubType,
                                                 radius=self.radius,
                                                 sourcePlayer=self.sourcePlayer))
                if self.blastType == "ice":
                    bs.playSound(Bomb.getFactory().freezeSound,10,position=t)
                    node.handleMessage(bs.FreezeMessage())
                    

                    
        elif isinstance(m,HealthMessage): # yeah, i am shit programmer!
            node = bs.getCollisionInfo("opposingNode")

            if node is not None and node.exists():
                if bs.getSharedObject('playerMaterial') in node.materials:
                    node.handleMessage(bs.PowerupMessage(powerupType = 'health'))

        else:
            bs.Actor.handleMessage(self,m)

class Bomb(bs.Actor):
    """
    category: Game Flow Classes
    
    A bomb and its variants such as land-mines and tnt-boxes.
    """

    def __init__(self,position=(0,1,0),velocity=(0,0,0),bombType='normal',blastRadius=2.0,sourcePlayer=None,owner=None,modelSize = 1,notShake = False,napalm = False,notSound = False):
        """
        Create a new Bomb.
        
        bombType can be 'ice','impact','landMine','normal','sticky', or 'tnt'.
        Note that for impact or landMine bombs you have to call arm()
        before they will go off.
        """
        bs.Actor.__init__(self)
        self.slipperPlanted = False
        self.aim = None
        self.slipperThree = False
        self.slipperThreeDropped = False
        factory = self.getFactory()
        self.napalm = napalm
        self.notSound = notSound
        
        self.notShake = notShake

        if not bombType in ('ice','impact','landMine','normal','sticky','tnt','forceBomb','agentHead','poison','agentHead','agentHead','heal','agentHead','shockWave','agentHead','agentHead','superMine','dirtBomb','foxicBomb','waterFire'): raise Exception("invalid bomb type: " + bombType)
        self.bombType = bombType

        self._exploded = False

        if self.bombType == 'sticky' or self.bombType == 'forceBomb': self._lastStickySoundTime = 0

        self.blastRadius = blastRadius
        if self.bombType == 'ice': self.blastRadius *= 1.2
        elif self.bombType == 'impact': self.blastRadius *= 0.7
        elif self.bombType == 'landMine': self.blastRadius *= 0.7
        elif self.bombType == 'tnt': self.blastRadius *= 1.45
        elif self.bombType == 'superMine': self.blastRadius *= 0.7        
        elif self.bombType == 'agentHead': self.blastRadius *= 2
        elif self.bombType == 'agentHead': self.blastRadius *= 0.6
        elif self.bombType == 'shockWave': self.blastRadius *= 0.2
        elif self.bombType == 'agentHead': self.blastRadius *= 2.5
        elif self.bombType == 'agentHead': self.blastRadius *= 0.5
        elif self.bombType == 'waterFire': self.blastRadius *= 0.5        
        self._explodeCallbacks = []
        
        # the player this came from
        self.sourcePlayer = sourcePlayer

        # by default our hit type/subtype is our own, but we pick up types of whoever
        # sets us off so we know what caused a chain reaction
        self.hitType = 'explosion'
        self.hitSubType = self.bombType

        # if no owner was provided, use an unconnected node ref
        if owner is None: owner = bs.Node(None)

        # the node this came from
        self.owner = owner

        # adding footing-materials to things can screw up jumping and flying since players carrying those things
        # and thus touching footing objects will think they're on solid ground..
        # perhaps we don't wanna add this even in the tnt case?..
        if self.bombType == 'tnt':
            materials = (factory.bombMaterial, bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))
        else:
            materials = (factory.bombMaterial, bs.getSharedObject('objectMaterial'))
            
        if self.bombType == 'impact' or self.bombType == 'agentHead' or self.bombType == 'poison' or self.bombType == 'agentHead' or self.bombType == 'heal' or self.bombType == 'agentHead' or self.bombType == 'forceBomb' or self.bombType == 'shockWave' or self.bombType == 'dirtBomb' or self.bombType == 'foxicBomb' or self.bombType == 'waterFire': materials = materials + (factory.impactBlastMaterial,)
        elif self.bombType == 'timeBomb': materials = materials + (factory.impactBlastMaterial,)
        elif self.bombType == 'landMine' or self.bombType == 'agentHead' or self.bombType == 'superMine': materials = materials + (factory.landMineNoExplodeMaterial,)

        if self.bombType == 'sticky': materials = materials + (factory.stickyMaterial,)
        else:
            if not self.notSound:
                materials = materials + (factory.normalSoundMaterial,)
        
        

        if self.bombType == 'landMine':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.landMineModel,
                                          'lightModel':factory.landMineModel,
                                          'body':'landMine',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.44,
                                          'colorTexture':factory.landMineTex,
                                          'reflection':'powerup',
                                          'reflectionScale':[1.0],
                                          'materials':materials})
                                          

        elif self.bombType == 'superMine':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.landMineModel,
                                          'lightModel':factory.landMineModel,
                                          'body':'landMine',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.44,
                                          'colorTexture':factory.superMineTex,
                                          'reflection':'powerup',
                                          'reflectionScale':[1.0],
                                          'materials':materials})


                                          
        elif self.bombType == 'forceBomb':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   owner=owner,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.stickyBombModel,
                                          'lightModel':factory.stickyBombModel,
                                          'body':'sphere',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.44,
                                          'colorTexture':factory.forceTex,
                                          'reflection':'powerup',
                                          'reflectionScale':[1.0],
                                          'materials':materials})
                                          
        elif self.bombType == 'heal':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'body':'sphere',
                                          'bodyScale':modelSize,
                                          'materials':materials})
                                          
            self.shield1 = bs.newNode('shield',owner=self.node,
                                     attrs={'color':(1,1,1),'radius':0.6})
            self.node.connectAttr('position',self.shield1,'position')
            
            self.shield2 = bs.newNode('shield',owner=self.node,
                                     attrs={'color':(20,0,0),'radius':0.4})
            self.node.connectAttr('position',self.shield2,'position')
            
            bs.animate(self.shield2,'radius',{0:0.1,300:0.5,600:0.1},True)
                                          

        elif self.bombType == 'tnt':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.tntModel,
                                          'lightModel':factory.tntModel,
                                          'body':'crate',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.5,
                                          'colorTexture':factory.tntTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.23],
                                          'materials':materials})
                                          
        elif self.bombType == 'agentHead':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.slipperModel,
                                          'body':'landMine',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.5,
                                          'density':0.7,
                                          'colorTexture':factory.slipperTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})
                                          
        elif self.bombType == 'agentHead':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.toxicModel,
                                          'body':'capsule',
                                          'bodyScale':0.84,
                                          'shadowSize':0.5,
                                          'colorTexture':factory.toxicTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})
                                          
        elif self.bombType == 'poison':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.poisonModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.5,
                                          'bodyScale':0.84,
                                          'colorTexture':factory.poisonTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})
                                          
        elif self.bombType == 'waterFire':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.waterFireModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize,
                                          'shadowSize':0.5,
                                          'bodyScale':0.84,
                                          'colorTexture':factory.waterFireTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})

        elif self.bombType == 'foxicBomb':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.foxicModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize,
                                          'shadowSize':1,
                                          'bodyScale':0.84,
                                          'colorTexture':factory.foxicTex,
                                          'reflection':'soft',
                                          'reflectionScale':[1],
                                          'materials':materials})

                                          
        elif self.bombType == 'dirtBomb':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.dirtModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize+0.4,
                                          'shadowSize':0.5,
                                          'bodyScale':0.88,
                                          'density':0.68,
                                          'colorTexture':factory.dirtTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})
                                          
        elif self.bombType == 'agentHead':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.bananaModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize+0.4,
                                          'shadowSize':0.5,
                                          'bodyScale':0.8,
                                          'density':1,
                                          'colorTexture':factory.bananaTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.4],
                                          'materials':materials})
                                          
        elif self.bombType == 'shockWave':
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.shockWaveModel,
                                          'body':'capsule',
                                          'bodyScale':modelSize+0.4,
                                          'shadowSize':0.5,
                                          'bodyScale':1,
                                          'modelScale':1.3,
                                          'colorTexture':factory.shockWaveTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.7],
                                          'materials':materials})
                                          
        elif self.bombType == 'agentHead':
            fuseTime = 4000
            self.node = bs.newNode('bomb',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':factory.petardModel,
                                          'shadowSize':0.3,
                                          'bodyScale':modelSize,
                                          'colorTexture':factory.petardTex,
                                          'reflection':'soft',
                                          'reflectionScale':[0.45],
                                          'materials':materials})
            if not self.notSound:
                sound = bs.newNode('sound',owner=self.node,attrs={'sound':factory.fuseSound,'volume':0.25})
                self.node.connectAttr('position',sound,'position')
            bsUtils.animate(self.node,'fuseLength',{0:1,fuseTime:0})
            
        elif self.bombType == 'impact':
            fuseTime = 20000
            self.node = bs.newNode('prop',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'body':'sphere',
                                          'model':factory.impactBombModel,
                                          'shadowSize':0.3,
                                          'bodyScale':modelSize,
                                          'colorTexture':factory.impactTex,
                                          'reflection':'powerup',
                                          'reflectionScale':[1.5],
                                          'materials':materials})
            self.armTimer = bs.Timer(200,bs.WeakCall(self.handleMessage,ArmMessage()))
            self.warnTimer = bs.Timer(fuseTime-1700,bs.WeakCall(self.handleMessage,WarnMessage()))

        else:
            fuseTime = 3000
            if self.bombType == 'sticky':
                sticky = True
                model = factory.stickyBombModel
                rType = 'sharper'
                rScale = 1.8
            else:
                sticky = False
                model = factory.bombModel
                rType = 'sharper'
                rScale = 1.8
            if self.bombType == 'ice': tex = factory.iceTex
            elif self.bombType == 'sticky': tex = factory.stickyTex
            elif self.bombType == 'agentHead':
                tex = factory.fireBottleTex
                model = factory.fireBottleModel
            else: tex = factory.regularTex
            bm = self.owner is not None and self.owner.exists() and self.owner.getDelegate().character == 'Bombman' and self.bombType == 'normal' and self.owner.headModel is not None
            self.node = bs.newNode('bomb',
                                   delegate=self,
                                   attrs={'position':position,
                                          'velocity':velocity,
                                          'model':bs.getModel('agentHead') if bm else model,
                                          'shadowSize':0.3,
                                          'bodyScale':modelSize,
                                          'colorTexture':bs.getTexture('BombmanColor') if bm else tex,
                                          'sticky':sticky,
                                          'owner':owner,
                                          'reflection':rType,
                                          'reflectionScale':[rScale],
                                          'materials':materials})
                                          
                                          
            if not self.notSound:
                sound = bs.newNode('sound',owner=self.node,attrs={'sound':factory.fuseSound,'volume':0.25})
                self.node.connectAttr('position',sound,'position')
            bsUtils.animate(self.node,'fuseLength',{0:1,fuseTime:0})

        # light the fuse!!!
        if self.bombType not in ('landMine','tnt','forceBomb','agentHead','poison','agentHead','agentHead','heal','agentHead','shockWave','superMine','dirtBomb','foxicBomb','waterFire'):
            bs.gameTimer(fuseTime,bs.WeakCall(self.handleMessage,ExplodeMessage()))

        bsUtils.animate(self.node,"modelScale",{0:0, 200:1.3, 260:1})

    def getSourcePlayer(self):
        """
        Returns a bs.Player representing the source of this bomb.
        """
        if self.sourcePlayer is None: return bs.Player(None) # empty player ref
        return self.sourcePlayer
        
    @classmethod
    def getFactory(cls):
        """
        Returns a shared bs.BombFactory object, creating it if necessary.
        """
        activity = bs.getActivity()
        try: return activity._sharedBombFactory
        except Exception:
            f = activity._sharedBombFactory = BombFactory()
            return f

    def onFinalize(self):
        bs.Actor.onFinalize(self)
        # release callbacks/refs so we don't wind up with dependency loops..
        self._explodeCallbacks = []
        
    def _handleDie(self,m):
        self.node.delete()
        
    def _handleOOB(self,m):
        self.handleMessage(bs.DieMessage())

    def _handleImpact(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'impact' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'impact' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
            
    def _handleToxic(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'agentHead' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'agentHead' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
 
    def _handleImpact(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'impact' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'impact' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())

    def _handleSuperMine(self,m,typeOfBomb):
        node, body = bs.getCollisionInfo('opposingNode', 'opposingBody')
        def go():
            # if we're an impact bomb and we came from this node, don't explode...
            # alternately if we're hitting another impact-bomb from the same source,
            # don't explode...
            try: nodeDelegate = node.getDelegate()
            except Exception: nodeDelegate = None
            if node is not None and node.exists():
                typeOfBombEdit = 'impact' if typeOfBomb == 'landMine' else typeOfBomb
                if (self.bombType == typeOfBombEdit and
                    (node is self.owner
                     or (isinstance(nodeDelegate, Bomb)
                         and nodeDelegate.bombType == typeOfBombEdit
                         and nodeDelegate.owner is self.owner))): return
                else:
                    self.handleMessage(ExplodeMessage())

        if type == 'superMine': bs.gameTimer(300, go)
        else: go()

           
    def _handlePoison(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'poison' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'poison' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())


    def _handleFoxic(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'foxicBomb' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'foxicBomb' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())


    def _handleWaterFire(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'waterFire' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'waterFire' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleDirt(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'dirtBomb' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'dirtBomb' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleShockWave(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'shockWave' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'shockWave' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleBanana(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'agentHead' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'agentHead' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleHeal(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'heal' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'heal' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleSlipper(self,m):
        node,body = bs.getCollisionInfo("opposingNode","opposingBody")
        # if we're an impact bomb and we came from this node, don't explode...
        # alternately if we're hitting another impact-bomb from the same source, don't explode...
        try: nodeDelegate = node.getDelegate()
        except Exception: nodeDelegate = None
        if node is not None and node.exists():
            if (self.bombType == 'agentHead' and
                (node is self.owner or (isinstance(nodeDelegate,Bomb) and nodeDelegate.bombType == 'agentHead' and nodeDelegate.owner is self.owner))): return
            else: self.handleMessage(ExplodeMessage())
            
    def _handleForceBomb(self,m):
        node = bs.getCollisionInfo("opposingNode")
        if self.node.exists():
            if node is not self.owner and bs.getSharedObject('playerMaterial') in node.materials:
                self.node.sticky = True
                def on():
                    self.node.extraAcceleration = (0,80,0)
                    #node.holdNode = self.node
                    if self.aim is not None:
                        self.aim.off()
                bs.gameTimer(2,on)

    def _handleDropped(self,m):
        if self.bombType == 'landMine':
            self.armTimer = bs.Timer(1250,bs.WeakCall(self.handleMessage,ArmMessage()))
        elif self.bombType == 'superMine':
            self.armTimer = bs.Timer(500,bs.WeakCall(self.handleMessage,ArmMessage()))            
        elif self.bombType == 'forceBomb':
            self.armTimer = bs.Timer(250,bs.WeakCall(self.handleMessage,ArmMessage()))
        elif self.bombType == 'agentHead':
            if not self.slipperThree:
                self.armTimer = bs.Timer(1250,bs.WeakCall(self.handleMessage,ArmMessage()))
                self.slipperPlanted = True
            else:
                self.slipperThreeDropped = True
                if self.node.exists():
                    def bl():
                        if self.node.exists():
                            bs.Blast(position = self.node.position,blastRadius = 0.2).autoRetain()
                    bs.gameTimer(1500,bs.Call(bl))
        # once we've thrown a sticky bomb we can stick to it..
        elif self.bombType == 'sticky':
            def _safeSetAttr(node,attr,value):
                if node.exists(): setattr(node,attr,value)
            #bs.gameTimer(250,bs.Call(_safeSetAttr,self.node,'stickToOwner',True))
            bs.gameTimer(250,lambda: _safeSetAttr(self.node,'stickToOwner',True))

    def _handleSplat(self,m):
        node = bs.getCollisionInfo("opposingNode")
        if node is not self.owner and bs.getGameTime() - self._lastStickySoundTime > 1000:
                    
            self._lastStickySoundTime = bs.getGameTime()
            bs.playSound(self.getFactory().stickyImpactSound,2.0,position=self.node.position)

    def addExplodeCallback(self,call):
        """
        Add a call to be run when the bomb has exploded.
        The bomb and the new blast object are passed as arguments.
        """
        self._explodeCallbacks.append(call)
        
    def explode(self):
        """
        Blows up the bomb if it has not yet done so.
        """
        if self._exploded: return
        self._exploded = True
        activity = self.getActivity()
        if not self.bombType in ['agentHead','poison','shockWave','foxicBomb']:
            if activity is not None and self.node.exists():
                if self.bombType == 'normal':
                    if self.owner is not None and self.owner.exists() and self.owner.getDelegate().character == 'Bombman' and self.owner.headModel is None:
                        self.owner.headModel = bs.getModel('agentHead')
                if self.napalm or self.bombType == 'waterFire':
                    bs.Napalm(position = self.node.position)
                blast = Blast(position=self.node.position,velocity=self.node.velocity,
                              blastRadius=self.blastRadius,blastType=self.bombType if not self.notShake else 'agentHead',sourcePlayer=self.sourcePlayer,hitType=self.hitType,hitSubType=self.hitSubType).autoRetain()
                for c in self._explodeCallbacks: c(self,blast)
                if self.bombType == 'agentHead':
                    def slowMo():
                        bs.getSharedObject('globals').slowMotion = bs.getSharedObject('globals').slowMotion == False
                    slowMo()
                    bs.playSound(bs.getSound("orchestraHitBig2"))
                    bs.gameTimer(600,bs.Call(slowMo))


                    
        elif self.bombType == 'agentHead':
            import portalObjects
            portalObjects.Toxic(position = self.node.position)
            bs.playSound(self.getFactory().toxicSound,position = self.node.position)
        elif self.bombType == 'poison':
            import portalObjects
            portalObjects.Poison(position = self.node.position)
            bs.playSound(self.getFactory().poisonSound,position = self.node.position)
        elif self.bombType == 'foxicBomb':
            import portalObjects
            portalObjects.AntiGravArea(position = self.node.position)
            bs.playSound(self.getFactory().foxicSound,position = self.node.position)            
        elif self.bombType == 'shockWave':
            import portalObjects
            portalObjects.ShockWave(position = self.node.position)
            bs.playSound(self.getFactory().shockWaveSound,position = self.node.position)
        elif self.bombType == 'agentHead':
            pass
            
        # we blew up so we need to go away
        bs.gameTimer(1,bs.WeakCall(self.handleMessage,bs.DieMessage()))

    def _handleWarn(self,m):
        if self.textureSequence.exists():
            self.textureSequence.rate = 30
            bs.playSound(self.getFactory().warnSound,0.5,position=self.node.position)

    def _addMaterial(self,material):
        if not self.node.exists(): return
        materials = self.node.materials
        if not material in materials:
            self.node.materials = materials + (material,)
        
    def arm(self):
        """
        Arms land-mines and impact-bombs so
        that they will explode on impact.
        """
        if not self.node.exists(): return
        factory = self.getFactory()
        if self.bombType == 'landMine':
            self.textureSequence = bs.newNode('textureSequence',
                                              owner=self.node,
                                              attrs={'inputTextures':(factory.landMineLitTex,
                                                                      factory.landMineTex),'rate':30})
            bs.gameTimer(500,self.textureSequence.delete)
            # we now make it explodable.
            bs.gameTimer(250,bs.WeakCall(self._addMaterial,factory.landMineBlastMaterial))
        elif self.bombType == 'superMine':
            self.textureSequence = bs.newNode('textureSequence',
                                              owner=self.node,
                                              attrs={'inputTextures':(factory.superMineLitTex,
                                                                      factory.superMineTex),'rate':30})
            bs.gameTimer(500,self.textureSequence.delete)
            self.aim = portalObjects.AutoAim(self.node, self.owner)            
            # we now make it explodable.
            bs.gameTimer(250,bs.WeakCall(self._addMaterial,factory.landMineBlastMaterial))            
        elif self.bombType == 'impact':
            self.textureSequence = bs.newNode('textureSequence',
                                              owner=self.node,
                                              attrs={'inputTextures':(factory.impactLitTex,
                                                                      factory.impactTex,
                                                                      factory.impactTex),'rate':100})
            bs.gameTimer(250,bs.WeakCall(self._addMaterial,factory.landMineBlastMaterial))
        elif self.bombType == 'forceBomb':
            #self.setSticky()
            bs.playSound(bs.getSound('activateBeep'),position = self.node.position)
            self.aim = portalObjects.AutoAim(self.node,self.owner)
            
        elif self.bombType == 'agentHead':
            bs.gameTimer(250,bs.WeakCall(self._addMaterial,factory.landMineBlastMaterial))
            bs.playSound(bs.getSound('bombHasBeenPlanted'))
        else:
            raise Exception('arm() should only be called on land-mines or impact bombs')
        if not self.bombType in ['forceBomb','agentHead']:
            self.textureSequence.connectAttr('outputTexture',self.node,'colorTexture')
            bs.playSound(factory.activateSound,0.5,position=self.node.position)
            
    def rearm(self):
        if not self.node.exists(): return
        factory = self.getFactory()
        if self.bombType == 'agentHead':
            self.node.materials = [bs.getSharedObject('objectMaterial')]
        def one():
            bs.playSound(bs.getSound("slipperOne"))
        def two():
            bs.playSound(bs.getSound("slipperTwo"))
        def three():
            bs.playSound(bs.getSound("slipperThree"))
        def blast():
            if self.node.exists():
                if not self.slipperThreeDropped:
                    bs.Blast(position = self.node.position,blastRadius = 1).autoRetain()
        def off():
            self.slipperThree = True
        bs.gameTimer(2000,bs.Call(one))
        bs.gameTimer(3500,bs.Call(two))
        bs.gameTimer(5000,bs.Call(three))
        bs.gameTimer(5100,bs.Call(off))
        bs.gameTimer(6600,bs.Call(blast))
        
        
        
    def _handleHit(self,m):
        isPunch = (m.srcNode.exists() and m.srcNode.getNodeType() == 'spaz')

        # normal bombs are triggered by non-punch impacts..  impact-bombs by all impacts
        if not self._exploded and not isPunch or self.bombType in ['impact','landMine','superMine']:
            # also lets change the owner of the bomb to whoever is setting us off..
            # (this way points for big chain reactions go to the person causing them)
            if m.sourcePlayer not in [None]:
                self.sourcePlayer = m.sourcePlayer

                # also inherit the hit type (if a landmine sets off by a bomb, the credit should go to the mine)
                # the exception is TNT.  TNT always gets credit.
                if self.bombType != 'tnt':
                    self.hitType = m.hitType
                    self.hitSubType = m.hitSubType

            bs.gameTimer(100+int(random.random()*100),bs.WeakCall(self.handleMessage,ExplodeMessage()))
        self.node.handleMessage("impulse",m.pos[0],m.pos[1],m.pos[2],
                                m.velocity[0],m.velocity[1],m.velocity[2],
                                m.magnitude,m.velocityMagnitude,m.radius,0,m.velocity[0],m.velocity[1],m.velocity[2])

        if m.srcNode.exists():
            pass
            #print 'FIXME HANDLE KICKBACK ON BOMB IMPACT'
            # bs.nodeMessage(m.srcNode,"impulse",m.srcBody,m.pos[0],m.pos[1],m.pos[2],
            #                     -0.5*m.force[0],-0.75*m.force[1],-0.5*m.force[2])
        
    def handleMessage(self,m):
        if isinstance(m,ExplodeMessage): self.explode()
        elif isinstance(m,ImpactMessage):
            if not self.bombType in ['agentHead','poison','agentHead','heal','agentHead','forceBomb','shockWave','dirtBomb','foxicBomb','waterFire']:
                self._handleImpact(m)
            elif self.bombType == 'agentHead':
                self._handleToxic(m)
            elif self.bombType == 'poison':
                self._handlePoison(m)
            elif self.bombType == 'foxicBomb':
                self._handleFoxic(m)                
            elif self.bombType == 'agentHead':
                self._handleSlipper(m)
            elif self.bombType == 'dirtBomb':
                self._handleDirt(m)
            elif self.bombType == 'heal':
                self._handleHeal(m)
            elif self.bombType == 'agentHead':
                self._handleBanana(m)
            elif self.bombType == 'forceBomb':
                self._handleForceBomb(m)
            elif self.bombType == 'waterFire':
                self._handleWaterFire(m)                
            elif self.bombType == 'shockWave':
                self._handleShockWave(m)
            elif self.bombType == 'superMine':
                self._handleSuperMine(m)                
        elif isinstance(m,bs.PickedUpMessage):
            # change our source to whoever just picked us up *only* if its None
            # this way we can get points for killing bots with their own bombs
            # hmm would there be a downside to this?...
            if self.bombType == 'agentHead':
                if self.slipperPlanted:
                    self.sourcePlayer = m.node.sourcePlayer
                    self.owner = m.node
                    self.rearm()
            elif self.bombType == 'superMine' \
                    and self.node.exists() \
                    and self.owner != m.node:
                bs.playSound(
                    bs.getSound('Aim'),
                    position=self.node.position)

                bsUtils.PopupText(
                    bs.Lstr(resource='SuperMineDefused'),
                    color=(0, 0, 1),
                    scale=1.0,
                    position=self.node.position).autoRetain()

                self.node.delete()

            if self.sourcePlayer is not None:
                self.sourcePlayer = m.node.sourcePlayer

        elif isinstance(m,SplatMessage):
            self._handleSplat(m)
        elif isinstance(m,bs.DroppedMessage):
            self._handleDropped(m)
        elif isinstance(m,SetStickyMessage): self.node.sticky = True
        elif isinstance(m,bs.HitMessage): self._handleHit(m)
        elif isinstance(m,bs.DieMessage): self._handleDie(m)
        elif isinstance(m,bs.OutOfBoundsMessage): self._handleOOB(m)
        elif isinstance(m,ArmMessage): self.arm()
        elif isinstance(m,WarnMessage): self._handleWarn(m)
        else: bs.Actor.handleMessage(self,m)

class TNTSpawner(object):
    """
    category: Game Flow Classes

    Regenerates TNT at a given point in space every now and then.
    """
    def __init__(self,position,respawnTime=30000):
        """
        Instantiate with a given position and respawnTime (in milliseconds).
        """
        self._position = position
        self._tnt = None
        self._update()
        self._updateTimer = bs.Timer(1000,bs.WeakCall(self._update),repeat=True)
        self._respawnTime = int(random.uniform(0.8,1.2)*respawnTime)
        self._waitTime = 0
        
    def _update(self):
        tntAlive = self._tnt is not None and self._tnt.node.exists()
        if not tntAlive:
            # respawn if its been long enough.. otherwise just increment our how-long-since-we-died value
            if self._tnt is None or self._waitTime >= self._respawnTime:
                self._tnt = Bomb(position=self._position,bombType='tnt')
                self._waitTime = 0
            else: self._waitTime += 1000
