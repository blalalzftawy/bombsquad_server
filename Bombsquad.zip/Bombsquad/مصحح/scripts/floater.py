import random
import bsUtils
import bsInternal
import bs
import math
class Floater(bs.Actor):
    def __init__(self,map):
        bs.Actor.__init__(self)
        self.floaterMaterial = bs.Material()
        self.floaterMaterial.addActions(conditions=('theyHaveMaterial', bs.getSharedObject('playerMaterial')),actions=(('modifyNodeCollision','collide',True),('modifyPartCollision','physical',True)))
        self.floaterMaterial.addActions(conditions=(
                        ('theyDontHaveMaterial', bs.getSharedObject('playerMaterial')), 'and',
                                    ('theyHaveMaterial', bs.getSharedObject('objectMaterial')), 'or',
                                                ('theyHaveMaterial', bs.getSharedObject('footingMaterial'))),
                                                            actions=(
                                                                                ('modifyPartCollision', 'physical', False),
                                                                                            ))
        self.pos = map.getDefBoundBox('levelBounds')
        self.px = "random.uniform(self.pos[0],self.pos[3])"
        self.py = "random.uniform(self.pos[1],self.pos[4])"
        self.pz = "random.uniform(self.pos[2],self.pos[5])"
        self.node = bs.newNode('prop',attrs={'position':(eval(self.px),eval(self.py),eval(self.pz)),'sticky':False,'body':'landMine','model':bs.getModel('frostyHead'),'colorTexture':bs.getTexture('frostyIcon'),'bodyScale':4.0,'reflection': 'powerup','density':99999999,'reflectionScale': [1.0],'modelScale':4.0,'gravityScale':0,'shadowSize':0.1,'isAreaOfInterest':True,'materials':[bs.Bomb.getFactory().landMineNoExplodeMaterial,bs.getSharedObject('footingMaterial'),self.floaterMaterial]},delegate = self)
        bs.gameTimer(500,bs.WeakCall(self.move))
        #bs.gameTimer(2000,bs.WeakCall(self.drop),True)
        self.move()

    def distance(self,x1, y1, z1, x2, y2, z2):
        d = math.sqrt(math.pow(x2 - x1, 2) +
                math.pow(y2 - y1, 2) +
                math.pow(z2 - z1, 2)* 1.0)

        return d

    def drop(self):
        try:
          np = self.node.position
        except:
          np = (0,0,0)
        self.b = bs.Bomb(bombType=random.choice(['normal','ice','sticky','impact','landMine','tnt']),position=(np[0],np[1]-1,np[2]),velocity=(0,-1,0)).autoRetain()
        if self.b.bombType in ['impact','landMine']:
            self.b.arm()
    def move(self):
        px = eval(self.px)
        py = eval(self.py)
        pz = eval(self.pz)
        try:
            if self.node.exists():
                pn = self.node.position
                # time = self.distance(pn[0],pn[1],pn[2],px,py,pz)*2000
                dist = self.distance(pn[0],pn[1],pn[2],px,py,pz)
        except:
            time = 1000
            print 'Floater Time Error'
        if self.node.exists():
            # bsUtils.animateArray(self.node,'position',3,{0:self.node.position,time:(px,py,pz)})
            # bs.gameTimer(int(round(time)),bs.WeakCall(self.move))
            self.node.velocity = ((px-pn[0])/dist,(py-pn[1])/dist,(pz-pn[2])/dist)
            bs.gameTimer(int(round(dist*1000)),bs.WeakCall(self.move))
    def handleMessage(self, m):
        super(self.__class__, self).handleMessage(m)
        if isinstance(m, bs.DieMessage):
            self.node.delete()
        elif isinstance(m, bs.OutOfBoundsMessage):
            self.node.position = (0,0,0)
        elif isinstance(m, bs.PickedUpMessage):
            #self.node.extraAcceleration = ((0-self.node.position[0]),25,(0-self.node.position[2]))
            self.node.extraAcceleration = (0,0,0)
        elif isinstance(m, bs.DroppedMessage):
            self.node.extraAcceleration = (0,0,0)
