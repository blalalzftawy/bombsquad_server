vipHashes = []
adminHashes = ['\xee\x80\xa0Google ID','\xee\x80\xb0PC ID','\xee\x80\xb0Android ID']


