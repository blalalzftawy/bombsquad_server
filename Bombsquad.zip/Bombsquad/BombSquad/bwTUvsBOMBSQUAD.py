import bs
import random
import bsSpaz

def bsGetAPIVersion():
	return 4

def bsGetGames():
	return [TUvsBombSquad]

def bsGetLevels():
	return [
            ## Original
            bs.Level('TUvsBombSquad Original',
			displayName='TUvsBS',
			gameType=TUvsBombSquad,
			settings={},
			previewTexName='footballStadiumPreview'),
            bs.Level('TUvsBombSquad Original Epic',
			displayName='TUvsBS Epic',
			gameType=TUvsBombSquad,
			settings={'Epic Mode':True},
			previewTexName='footballStadiumPreview'),
            
            ## Low Edit
            bs.Level('TUvsBombSquad Low Edit',
			displayName='TUvsBS Low Edit',
			gameType=TUvsBombSquad,
			settings={'Low Edit':True},
			previewTexName='footballStadiumPreview'),
            bs.Level('TUvsBombSquad Low Edit Epic',
			displayName='TUvsBS Low Edit Epic',
			gameType=TUvsBombSquad,
			settings={'Epic Mode':True,'Low Edit':True},
			previewTexName='footballStadiumPreview')]
            
#### BOTS ####
class SpazBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Spaz'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.1,0.35,0.1)
    highlight=(1,0.15,0.15)
	
class ZoeBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Zoe'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.6,0.6,0.6)
    highlight=(0,1,0)

class SnakeBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Snake Shadow'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,1,1)
    highlight=(0.55,0.8,0.55)
	
class MelBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Mel'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,1,1)
    highlight=(0.1,0.6,0.1)
	
class JackBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Jack Morgan'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,0.2,0.1)
    highlight=(1,1,0)
	
class SantaBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Santa Claus'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,0,0)
    highlight=(1,1,1)

class FrostyBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Frosty'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.5,0.5,1)
    highlight=(1,0.5,0)
	
class BonesBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Bones'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.6,0.9,1)
    highlight=(0.6,0.9,1)
	
class BernardBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Bernard'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.7,0.5,0.0)
    highlight=(0.6,0.5,0.8)
	
class PascalBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Pascal'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.3,0.5,0.8)
    highlight=(1,0,0)
	
class TaobaoBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Taobao Mascot'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,0.5,0)
    highlight=(1,1,1)

class BBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'B-9000'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.5,0.5,0.5)
    highlight=(1,0,0)
	
class AgentBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Agent Johnson'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.3,0.3,0.33)
    highlight=(1,0.5,0.3)
	
class GrumbledorfBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Grumbledorf'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0.2,0.4,1.0)
    highlight=(0.06,0.15,0.4)

class PixelBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Pixel'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(0,1,0.7)
    highlight=(0.65,0.35,0.75)
	
class BunnyBot(bsSpaz.SpazBot):
    """
    category: Bot Classes
    
    A manly bot who walks and punches things.
    """
    character = 'Easter Bunny'
    punchiness = 0.9
    chargeDistMax = 9999.0
    chargeSpeedMin = 1.0
    chargeSpeedMax = 1.0
    throwDistMin = 9999
    throwDistMax = 9999
    color=(1,1,1)
    highlight=(1,0.5,0.5)
    
	
class TUvsBombSquad(bs.TeamGameActivity):

    @classmethod
    def getName(cls):
        return 'Tu vs BombSquad'

    @classmethod
    def getScoreInfo(cls):
        return {'scoreType':'milliseconds',
				'lowerIsBetter':True,
				'scoreName':'Time'}

    @classmethod
    def getDescription(cls,sessionType):
        return 'Elimina a todos los enemigos'

    @classmethod
    def getSupportedMaps(cls,sessionType):
        return ['Football Stadium']

    @classmethod
    def getSettings(cls,sessionType):
        return [("Epic Mode",{'default':False}),
                ("Low Edit",{'default':False})]
        
    @classmethod
    def supportsSessionType(cls,sessionType):
        # we currently support Co-Op only
        return True if issubclass(sessionType,bs.CoopSession) else False

    # in the constructor we should load any media we need/etc.
    # but not actually create anything yet.
    def __init__(self,settings):
        bs.TeamGameActivity.__init__(self,settings)
        self._winSound = bs.getSound("score")
        if self.settings['Epic Mode']:
            self._isSlowMotion = True
        if self.settings['Low Edit']:
            self._lowEdit = True

    # called when our game is transitioning in but not ready to start..
    # ..we can go ahead and start creating stuff, playing music, etc.
    def onTransitionIn(self):
        bs.TeamGameActivity.onTransitionIn(self, music='Epic' if self.settings['Epic Mode'] else 'Survival')

    # called when our game actually starts
    def onBegin(self):
        bs.TeamGameActivity.onBegin(self)
        self._won = False
        self.setupStandardPowerupDrops()
        self._timer = bs.OnScreenTimer()
        bs.gameTimer(4000,self._timer.start)

        playerCount = len(self.initialPlayerInfo)
 
        self._bots = bs.BotSet()

        self._low = self.settings['Low Edit']
        time2 = 5000 if self._low else 0
        time3 = 15000 if self._low else 0
        
        if not self._low:
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
                pos=(11.414681236, 0.9515026107, -5.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
                pos=(-11.555402285, 0.9515026107, -5.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
                pos=(11.414681236, 0.9515026107, -3.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(-11.555402285, 0.9515026107, -3.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(11.414681236, 0.9515026107, -1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(-11.555402285, 0.9515026107, -1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(11.414681236, 0.9515026107, 1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
                pos=(-11.555402285, 0.9515026107, 1.037912441),spawnTime=3000))
                
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
            pos=(11.414681236, 0.9515026107, -5.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
            pos=(-11.555402285, 0.9515026107, -5.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
            pos=(11.414681236, 0.9515026107, -3.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
            pos=(-11.555402285, 0.9515026107, -3.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
            pos=(11.414681236, 0.9515026107, -1.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
            pos=(-11.555402285, 0.9515026107, -1.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
            pos=(11.414681236, 0.9515026107, 1.037912441),spawnTime=3000))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
            pos=(-11.555402285, 0.9515026107, 1.037912441),spawnTime=3000))
 
        if not self._low: 
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
                pos=(8.414681236, 0.9515026107, -5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
                pos=(-8.555402285, 0.9515026107, -5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
                pos=(8.414681236, 0.9515026107, -3.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
                pos=(-8.555402285, 0.9515026107, -3.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(8.414681236, 0.9515026107, -1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(-8.555402285, 0.9515026107, -1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(-8.555402285, 0.9515026107, 1.037912441),spawnTime=5000))
            
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
            pos=(8.414681236, 0.9515026107, -5.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
            pos=(-8.555402285, 0.9515026107, -5.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
            pos=(8.414681236, 0.9515026107, -3.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
            pos=(-8.555402285, 0.9515026107, -3.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
            pos=(8.414681236, 0.9515026107, -1.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
            pos=(-8.555402285, 0.9515026107, -1.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
            pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
            pos=(-8.555402285, 0.9515026107, 1.037912441),spawnTime=5000+time2))
 
        if not self._low:  
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
                pos=(5.414681236, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
                pos=(-5.555402285, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
                pos=(5.414681236, 0.9515026107, -3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
                pos=(-5.555402285, 0.9515026107, -3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
                pos=(5.414681236, 0.9515026107, -1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(-5.555402285, 0.9515026107, -1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(5.414681236, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
                pos=(-5.555402285, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(5.414681236, 0.9515026107, 5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(-5.555402285, 0.9515026107, 5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
                pos=(5.414681236, 0.9515026107, -3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
                pos=(-5.555402285, 0.9515026107, -3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(5.414681236, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
                pos=(-5.555402285, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
                pos=(5.414681236, 0.9515026107, -1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
                pos=(-5.555402285, 0.9515026107, -1.037912441),spawnTime=8000))
                
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
            pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
            pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
            pos=(5.414681236, 0.9515026107, -5.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
            pos=(-5.555402285, 0.9515026107, -5.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
            pos=(5.414681236, 0.9515026107, -3.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
            pos=(-5.555402285, 0.9515026107, -3.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
            pos=(5.414681236, 0.9515026107, -1.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
            pos=(-5.555402285, 0.9515026107, -1.037912441),spawnTime=8000+time3))
 
        if not self._low:   
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(5.414681236, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(-5.555402285, 0.9515026107, -5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
                pos=(5.414681236, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
                pos=(-5.555402285, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
                pos=(5.414681236, 0.9515026107, 5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
                pos=(-5.555402285, 0.9515026107, 5.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
                pos=(5.414681236, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
                pos=(-5.555402285, 0.9515026107, 3.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
                pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
                
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
            pos=(5.414681236, 0.9515026107, 5.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
            pos=(-5.555402285, 0.9515026107, 5.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
            pos=(5.414681236, 0.9515026107, 3.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
            pos=(-5.555402285, 0.9515026107, 3.037912441),spawnTime=8000+time3))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
            pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000+time3))

        if not self._low:          
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
            pos=(5.414681236, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
                pos=(-5.555402285, 0.9515026107, 1.037912441),spawnTime=8000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
                pos=(-11.555402285, 0.9515026107, 1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,MelBot,
                pos=(11.414681236, 0.9515026107, 1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,JackBot,
                pos=(-11.555402285, 0.9515026107, 1.037912441),spawnTime=3000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SantaBot,
                pos=(8.414681236, 0.9515026107, 5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,FrostyBot,
                pos=(-8.555402285, 0.9515026107, 5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BonesBot,
                pos=(8.414681236, 0.9515026107, 3.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BernardBot,
                pos=(-8.555402285, 0.9515026107, 3.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PascalBot,
                pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,TaobaoBot,
                pos=(-8.555402285, 0.9515026107, 1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BBot,
                pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,AgentBot,
                pos=(-8.555402285, 0.9515026107, 1.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,GrumbledorfBot,
                pos=(8.414681236, 0.9515026107, 5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,PixelBot,
                pos=(-8.555402285, 0.9515026107, 5.037912441),spawnTime=5000))
            bs.gameTimer(4000,bs.Call(self._bots.spawnBot,BunnyBot,
                pos=(8.414681236, 0.9515026107, 3.037912441),spawnTime=5000))

        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SpazBot,
            pos=(-8.555402285, 0.9515026107, 3.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,ZoeBot,
            pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,SnakeBot,
            pos=(-8.555402285, 0.9515026107, 1.037912441),spawnTime=5000+time2))
        bs.gameTimer(4000,bs.Call(self._bots.spawnBot,bs.ToughGuyBot,
            pos=(8.414681236, 0.9515026107, 1.037912441),spawnTime=5000+time2))


    # called for each spawning player
    def spawnPlayer(self,player):

        # lets spawn close to the center
        spawnCenter = (0.07287520555, 0.02275111462, -1.988876512)
        pos = (spawnCenter[0]+random.uniform(0,0),spawnCenter[1],spawnCenter[2]+random.uniform(0,0))

        self.spawnPlayerSpaz(player,position=pos)

    def _checkIfWon(self):
        # simply end the game if there's no living bots..
        if not self._bots.haveLivingBots():
            self._won = True
            self.endGame()

    # called for miscellaneous events
    def handleMessage(self,m):

        # a player has died
        if isinstance(m,bs.PlayerSpazDeathMessage):
            bs.TeamGameActivity.handleMessage(self,m) # do standard stuff
            self.respawnPlayer(m.spaz.getPlayer()) # kick off a respawn

        # a spaz-bot has died
        elif isinstance(m,bs.SpazBotDeathMessage):
            # unfortunately the bot-set will always tell us there are living
            # bots if we ask here (the currently-dying bot isn't officially marked dead yet)
            # ..so lets push a call into the event loop to check once this guy has finished dying.
            bs.pushCall(self._checkIfWon)

        else:
            # let the base class handle anything we don't..
            bs.TeamGameActivity.handleMessage(self,m)

    # when this is called, we should fill out results and end the game
    # *regardless* of whether is has been won. (this may be called due
    # to a tournament ending or other external reason)
    def endGame(self):

        # stop our on-screen timer so players can see what they got
        self._timer.stop()

        results = bs.TeamGameResults()

        # if we won, set our score to the elapsed time
        # (there should just be 1 team here since this is co-op)
        # ..if we didn't win, leave scores as default (None) which means we lost
        if self._won:
            elapsedTime = bs.getGameTime()-self._timer.getStartTime()
            self.cameraFlash()
            bs.playSound(self._winSound)
            for team in self.teams:
                team.celebrate() # woooo! par-tay!
                results.setTeamScore(team,elapsedTime)

        # ends this activity..
        self.end(results)
