vipHashes = []
adminHashes = ['\xee\x80\xa0Google ID','\xee\x80\xb0PC ID','\xee\x80\xb0Android ID']
legendaryHashes = []
heroHashes = []
fighterHashes = []
tigerHashes = []

#adminHashes and legendaryHashes is the best permissions in my versoin